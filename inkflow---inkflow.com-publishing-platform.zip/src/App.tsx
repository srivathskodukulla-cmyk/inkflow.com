import { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { ReaderFeed } from './components/ReaderFeed';
import { MarkdownEditor } from './components/MarkdownEditor';
import { AudienceAnalytics } from './components/AudienceAnalytics';
import { MyStories } from './components/MyStories';
import { ArticleReader } from './components/ArticleReader';
import { PremiumModal } from './components/PremiumModal';
import { ShareModal } from './components/ShareModal';
import { DomainSettingsModal } from './components/DomainSettingsModal';
import { Post, UserProfile, PremiumTier } from './types';
import { INITIAL_POSTS, CURRENT_USER, INITIAL_ANALYTICS } from './data/mockData';

export default function App() {
  // Load state from localStorage with fallback to initial mock data
  const [posts, setPosts] = useState<Post[]>(() => {
    const saved = localStorage.getItem('inkflow_posts_v1');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse saved posts', e);
      }
    }
    return INITIAL_POSTS;
  });

  const [currentUser, setCurrentUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('inkflow_user_v1');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse saved user', e);
      }
    }
    return CURRENT_USER;
  });

  const [currentTab, setCurrentTab] = useState<'feed' | 'editor' | 'analytics' | 'my-stories' | 'reader'>('feed');
  const [activeReadingPost, setActiveReadingPost] = useState<Post | null>(null);
  const [editingPost, setEditingPost] = useState<Post | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('All Stories');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Track recently read article IDs with localStorage persistence
  const [recentlyReadIds, setRecentlyReadIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('inkflow_recently_read_v1');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse recently read posts', e);
      }
    }
    return ['post-1', 'post-3'];
  });

  // Modals state
  const [isPremiumModalOpen, setIsPremiumModalOpen] = useState<boolean>(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState<boolean>(false);
  const [isDomainModalOpen, setIsDomainModalOpen] = useState<boolean>(false);
  const [shareTargetPost, setShareTargetPost] = useState<Post | null>(null);

  // Sync state to localStorage
  useEffect(() => {
    localStorage.setItem('inkflow_posts_v1', JSON.stringify(posts));
  }, [posts]);

  useEffect(() => {
    localStorage.setItem('inkflow_user_v1', JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('inkflow_recently_read_v1', JSON.stringify(recentlyReadIds));
  }, [recentlyReadIds]);

  // Handlers
  const handleSelectTab = (tab: 'feed' | 'editor' | 'analytics' | 'my-stories') => {
    if (tab === 'editor' && !editingPost) {
      // If going to editor with no active editing post, set to null (new draft)
      setEditingPost(null);
    }
    setCurrentTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectPost = (post: Post) => {
    // Update recently read article IDs (prepend current post ID, deduplicate, limit to 10)
    setRecentlyReadIds((prev) => [post.id, ...prev.filter((id) => id !== post.id)].slice(0, 10));

    // Increment view count for the post
    const updated = posts.map((p) =>
      p.id === post.id ? { ...p, viewsCount: p.viewsCount + 1 } : p
    );
    setPosts(updated);
    setActiveReadingPost(post);
    setCurrentTab('reader');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleClearRecentlyRead = () => {
    setRecentlyReadIds([]);
  };

  const handleRemoveRecentlyRead = (postId: string) => {
    setRecentlyReadIds((prev) => prev.filter((id) => id !== postId));
  };

  const handleEditPost = (post: Post) => {
    setEditingPost(post);
    setCurrentTab('editor');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNewStory = () => {
    setEditingPost(null);
    setCurrentTab('editor');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSavePost = (partialPost: Partial<Post>, shouldPublish: boolean) => {
    const existingIndex = posts.findIndex((p) => p.id === partialPost.id);

    if (existingIndex >= 0) {
      const updatedPost: Post = {
        ...posts[existingIndex],
        ...partialPost,
        status: shouldPublish ? 'published' : 'draft',
        updatedAt: new Date().toISOString(),
      } as Post;

      const newPosts = [...posts];
      newPosts[existingIndex] = updatedPost;
      setPosts(newPosts);
      setEditingPost(updatedPost);
    } else {
      const newPost: Post = {
        id: partialPost.id || `post-${Date.now()}`,
        title: partialPost.title || 'Untitled Story',
        subtitle: partialPost.subtitle || '',
        slug: partialPost.slug || `story-${Date.now()}`,
        content: partialPost.content || '',
        coverImage: partialPost.coverImage || 'https://images.unsplash.com/photo-1499750310107-5fef28a66643?w=1200&auto=format&fit=crop&q=80',
        tags: partialPost.tags || ['Writing'],
        category: partialPost.category || 'Design & Craft',
        author: {
          id: currentUser.id,
          name: currentUser.name,
          handle: currentUser.handle,
          avatar: currentUser.avatar,
          bio: currentUser.bio,
          tier: currentUser.tier,
          followersCount: currentUser.followersCount,
          isVerified: true,
        },
        status: shouldPublish ? 'published' : 'draft',
        publishedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        readTime: partialPost.readTime || 4,
        wordCount: partialPost.wordCount || 800,
        isPremium: partialPost.isPremium ?? false,
        paywallType: partialPost.paywallType || 'free',
        premiumPrice: partialPost.premiumPrice || 0,
        claps: 0,
        bookmarksCount: 0,
        viewsCount: 1,
        readsCount: 0,
        commentsCount: 0,
        sharesCount: 0,
        allowComments: true,
      };

      setPosts([newPost, ...posts]);
      setEditingPost(newPost);
    }
  };

  const handleDeletePost = (postId: string) => {
    setPosts(posts.filter((p) => p.id !== postId));
  };

  const handleOpenShareModal = (post: Post) => {
    setShareTargetPost(post);
    setIsShareModalOpen(true);
  };

  const handleUpgradeSuccess = (tier: PremiumTier) => {
    setCurrentUser((prev) => ({
      ...prev,
      tier,
      subscriptionActive: true,
      subscriptionRenewDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(),
    }));
  };

  const handleUpdatePostClaps = (postId: string, newClaps: number) => {
    setPosts((prev) =>
      prev.map((p) => (p.id === postId ? { ...p, claps: newClaps } : p))
    );
  };

  return (
    <div className="min-h-screen flex flex-col bg-neutral-50 text-neutral-900 font-sans-custom">
      
      {/* Global Navigation Bar */}
      <Navbar
        currentTab={currentTab === 'reader' ? 'feed' : currentTab}
        onSelectTab={handleSelectTab}
        currentUser={currentUser}
        onOpenPremiumModal={() => setIsPremiumModalOpen(true)}
        onOpenDomainModal={() => setIsDomainModalOpen(true)}
        onNewStory={handleNewStory}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      {/* Main Content Body */}
      <main className="flex-1">
        {currentTab === 'feed' && (
          <ReaderFeed
            posts={posts}
            currentUser={currentUser}
            selectedCategory={selectedCategory}
            onSelectCategory={setSelectedCategory}
            searchQuery={searchQuery}
            recentlyReadIds={recentlyReadIds}
            onClearRecentlyRead={handleClearRecentlyRead}
            onRemoveRecentlyRead={handleRemoveRecentlyRead}
            onSelectPost={handleSelectPost}
            onOpenShareModal={handleOpenShareModal}
            onOpenPremiumModal={() => setIsPremiumModalOpen(true)}
            onNewStory={handleNewStory}
          />
        )}

        {currentTab === 'editor' && (
          <MarkdownEditor
            post={editingPost}
            currentUser={currentUser}
            onSave={handleSavePost}
            onOpenShareModal={handleOpenShareModal}
            onOpenPremiumModal={() => setIsPremiumModalOpen(true)}
            onBackToFeed={() => handleSelectTab('feed')}
          />
        )}

        {currentTab === 'analytics' && (
          <AudienceAnalytics
            analytics={INITIAL_ANALYTICS}
            posts={posts}
            currentUser={currentUser}
            onOpenPremiumModal={() => setIsPremiumModalOpen(true)}
            onSelectPost={handleSelectPost}
          />
        )}

        {currentTab === 'my-stories' && (
          <MyStories
            posts={posts}
            currentUser={currentUser}
            onEditPost={handleEditPost}
            onSelectPost={handleSelectPost}
            onOpenShareModal={handleOpenShareModal}
            onOpenPremiumModal={() => setIsPremiumModalOpen(true)}
            onNewStory={handleNewStory}
            onDeletePost={handleDeletePost}
          />
        )}

        {currentTab === 'reader' && activeReadingPost && (
          <ArticleReader
            post={activeReadingPost}
            currentUser={currentUser}
            onBack={() => handleSelectTab('feed')}
            onOpenShareModal={handleOpenShareModal}
            onOpenPremiumModal={() => setIsPremiumModalOpen(true)}
            onUpdatePostClaps={handleUpdatePostClaps}
          />
        )}
      </main>

      {/* Footer (Only on Feed and Analytics) */}
      {(currentTab === 'feed' || currentTab === 'analytics' || currentTab === 'my-stories') && (
        <footer className="border-t border-neutral-200 bg-white py-8 mt-16 text-xs text-neutral-500">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-neutral-900">Inkflow</span>
              <span>•</span>
              <span className="font-mono text-neutral-700 font-semibold">inkflow.com</span>
              <span>•</span>
              <span>Publishing Platform & Audience Analytics</span>
            </div>

            <div className="flex items-center gap-4">
              <button
                onClick={() => setIsDomainModalOpen(true)}
                className="text-indigo-600 hover:text-indigo-800 font-semibold"
              >
                Domain: inkflow.com
              </button>
              <button 
                onClick={() => setIsPremiumModalOpen(true)}
                className="text-amber-700 hover:text-amber-900 font-bold"
              >
                Writer Pro Share Pass
              </button>
              <button 
                onClick={() => handleSelectTab('analytics')}
                className="hover:text-neutral-900"
              >
                Audience Analytics
              </button>
              <button 
                onClick={() => handleSelectTab('editor')}
                className="hover:text-neutral-900"
              >
                Markdown Studio
              </button>
            </div>
          </div>
        </footer>
      )}

      {/* Modal Dialogs */}
      <PremiumModal
        isOpen={isPremiumModalOpen}
        onClose={() => setIsPremiumModalOpen(false)}
        currentUser={currentUser}
        onUpgradeSuccess={handleUpgradeSuccess}
      />

      <ShareModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        post={shareTargetPost}
        currentUser={currentUser}
        onOpenPremiumModal={() => setIsPremiumModalOpen(true)}
      />

      <DomainSettingsModal
        isOpen={isDomainModalOpen}
        onClose={() => setIsDomainModalOpen(false)}
      />

    </div>
  );
}
