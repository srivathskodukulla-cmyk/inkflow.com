import { useState } from 'react';
import { 
  PenTool, 
  Compass, 
  BarChart3, 
  BookOpen, 
  Sparkles, 
  Plus, 
  Search, 
  Crown,
  CheckCircle2,
  Share2,
  Globe
} from 'lucide-react';
import { UserProfile } from '../types';

interface NavbarProps {
  currentTab: 'feed' | 'editor' | 'analytics' | 'my-stories';
  onSelectTab: (tab: 'feed' | 'editor' | 'analytics' | 'my-stories') => void;
  currentUser: UserProfile;
  onOpenPremiumModal: () => void;
  onOpenDomainModal: () => void;
  onNewStory: () => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  currentUser,
  onOpenPremiumModal,
  onOpenDomainModal,
  onNewStory,
  searchQuery,
  onSearchChange,
}) => {
  const [showSearchInput, setShowSearchInput] = useState(false);

  return (
    <header id="main-header" className="sticky top-0 z-40 w-full border-b border-neutral-200/80 bg-white/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Brand Logo & Tagline */}
          <div className="flex items-center gap-6 sm:gap-8">
            <button
              id="brand-logo-btn"
              onClick={() => onSelectTab('feed')}
              className="flex items-center gap-2.5 text-left group cursor-pointer focus:outline-none"
            >
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-500 flex items-center justify-center text-white shadow-sm shadow-indigo-500/20 group-hover:scale-105 transition-transform duration-200">
                <PenTool className="w-5 h-5" />
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-extrabold tracking-tight text-neutral-900 font-sans-custom flex items-center gap-1.5">
                  Inkflow
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-100/80">
                  inkflow.com
                </span>
              </div>
            </button>

            {/* Desktop Navigation Links */}
            <nav id="desktop-nav" className="hidden md:flex items-center gap-1">
              <button
                id="nav-tab-feed"
                onClick={() => onSelectTab('feed')}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-colors ${
                  currentTab === 'feed'
                    ? 'bg-neutral-100 text-neutral-900 font-semibold'
                    : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-50'
                }`}
              >
                <Compass className="w-4 h-4" />
                Explore
              </button>

              <button
                id="nav-tab-editor"
                onClick={() => onSelectTab('editor')}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-colors ${
                  currentTab === 'editor'
                    ? 'bg-neutral-100 text-neutral-900 font-semibold'
                    : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-50'
                }`}
              >
                <PenTool className="w-4 h-4" />
                Writer Studio
              </button>

              <button
                id="nav-tab-analytics"
                onClick={() => onSelectTab('analytics')}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-colors ${
                  currentTab === 'analytics'
                    ? 'bg-neutral-100 text-neutral-900 font-semibold'
                    : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-50'
                }`}
              >
                <BarChart3 className="w-4 h-4" />
                Audience Analytics
              </button>

              <button
                id="nav-tab-my-stories"
                onClick={() => onSelectTab('my-stories')}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-colors ${
                  currentTab === 'my-stories'
                    ? 'bg-neutral-100 text-neutral-900 font-semibold'
                    : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-50'
                }`}
              >
                <BookOpen className="w-4 h-4" />
                My Stories
              </button>
            </nav>
          </div>

          {/* Right Action Area */}
          <div className="flex items-center gap-2.5 sm:gap-3">
            {/* Domain & Hosting Manager CTA */}
            <button
              id="domain-manager-btn"
              onClick={onOpenDomainModal}
              className="hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-neutral-200 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-50 text-xs font-medium transition-colors"
              title="View Domain & DNS settings for inkflow.com"
            >
              <Globe className="w-3.5 h-3.5 text-indigo-600" />
              <span className="font-mono text-[11px]">inkflow.com</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            </button>
            {/* Search Bar */}
            <div className="relative flex items-center">
              {showSearchInput ? (
                <div className="relative flex items-center">
                  <Search className="w-4 h-4 absolute left-3 text-neutral-400 pointer-events-none" />
                  <input
                    id="nav-search-input"
                    type="text"
                    placeholder="Search stories, tags..."
                    value={searchQuery}
                    onChange={(e) => onSearchChange(e.target.value)}
                    autoFocus
                    onBlur={() => {
                      if (!searchQuery) setShowSearchInput(false);
                    }}
                    className="w-48 sm:w-64 pl-9 pr-3 py-1.5 text-xs sm:text-sm bg-neutral-100 border border-neutral-200 rounded-full focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:bg-white transition-all"
                  />
                </div>
              ) : (
                <button
                  id="toggle-search-btn"
                  onClick={() => setShowSearchInput(true)}
                  className="p-2 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 rounded-full transition-colors"
                  title="Search stories"
                >
                  <Search className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Premium Membership Status / Upgrade CTA */}
            {currentUser.subscriptionActive ? (
              <button
                id="active-subscription-badge"
                onClick={onOpenPremiumModal}
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold bg-gradient-to-r from-amber-500/10 to-orange-500/10 text-amber-800 border border-amber-300/60 hover:border-amber-400 transition-colors"
              >
                <Crown className="w-3.5 h-3.5 text-amber-600 fill-amber-500" />
                <span>Writer Pro Active</span>
                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
              </button>
            ) : (
              <button
                id="unlock-sharing-premium-btn"
                onClick={onOpenPremiumModal}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white shadow-sm shadow-amber-500/25 transition-all hover:scale-105 active:scale-95"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Unlock Sharing</span>
                <span className="sm:hidden">Share</span>
                <span className="bg-white/20 px-1.5 py-0.2 rounded text-[10px] font-extrabold uppercase">
                  Pro
                </span>
              </button>
            )}

            {/* Write / New Story Button */}
            <button
              id="new-story-btn"
              onClick={onNewStory}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-white text-xs sm:text-sm font-semibold transition-colors shadow-sm"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Write</span>
            </button>

            {/* User Profile Avatar */}
            <div className="flex items-center gap-2 pl-2 border-l border-neutral-200">
              <img
                id="user-avatar-img"
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-8 h-8 rounded-full object-cover ring-2 ring-indigo-500/30"
              />
            </div>
          </div>

        </div>

        {/* Mobile Navigation bar */}
        <div className="flex md:hidden items-center justify-around py-2 border-t border-neutral-100 text-xs font-medium text-neutral-600">
          <button
            onClick={() => onSelectTab('feed')}
            className={`flex flex-col items-center gap-1 py-1 px-2 ${
              currentTab === 'feed' ? 'text-indigo-600 font-bold' : ''
            }`}
          >
            <Compass className="w-4 h-4" />
            <span>Feed</span>
          </button>
          <button
            onClick={() => onSelectTab('editor')}
            className={`flex flex-col items-center gap-1 py-1 px-2 ${
              currentTab === 'editor' ? 'text-indigo-600 font-bold' : ''
            }`}
          >
            <PenTool className="w-4 h-4" />
            <span>Studio</span>
          </button>
          <button
            onClick={() => onSelectTab('analytics')}
            className={`flex flex-col items-center gap-1 py-1 px-2 ${
              currentTab === 'analytics' ? 'text-indigo-600 font-bold' : ''
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>Analytics</span>
          </button>
          <button
            onClick={() => onSelectTab('my-stories')}
            className={`flex flex-col items-center gap-1 py-1 px-2 ${
              currentTab === 'my-stories' ? 'text-indigo-600 font-bold' : ''
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Stories</span>
          </button>
        </div>

      </div>
    </header>
  );
};
