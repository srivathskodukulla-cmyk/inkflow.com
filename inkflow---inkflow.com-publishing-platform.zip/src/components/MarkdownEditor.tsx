import React, { useState, useRef, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { 
  Bold, 
  Italic, 
  Strikethrough, 
  Heading1, 
  Heading2, 
  Heading3, 
  Quote, 
  Code, 
  List, 
  ListOrdered, 
  CheckSquare, 
  Link as LinkIcon, 
  Image as ImageIcon, 
  Table as TableIcon, 
  Minus, 
  Eye, 
  Columns, 
  FileText, 
  Settings, 
  Share2, 
  Sparkles, 
  Check, 
  ArrowLeft, 
  Lock, 
  DollarSign, 
  Tag, 
  FolderPlus,
  Clock,
  Crown
} from 'lucide-react';
import { Post, UserProfile, PaywallType } from '../types';
import { CATEGORIES } from '../data/mockData';

interface MarkdownEditorProps {
  post: Post | null;
  currentUser: UserProfile;
  onSave: (post: Partial<Post>, shouldPublish: boolean) => void;
  onOpenShareModal: (post: Post) => void;
  onOpenPremiumModal: () => void;
  onBackToFeed: () => void;
}

export const MarkdownEditor: React.FC<MarkdownEditorProps> = ({
  post,
  currentUser,
  onSave,
  onOpenShareModal,
  onOpenPremiumModal,
  onBackToFeed,
}) => {
  const [title, setTitle] = useState(post?.title || '');
  const [subtitle, setSubtitle] = useState(post?.subtitle || '');
  const [content, setContent] = useState(
    post?.content || `# Enter your story title here\n\nStart writing in markdown. You can use **bold**, *italics*, [links](https://inkflow.com), and custom code snippets.\n\n> "Writing is the painting of the voice." — Voltaire\n\n## Subheading Example\n\nWrite your thoughts with clarity and purpose.`
  );
  const [coverImage, setCoverImage] = useState(
    post?.coverImage || 'https://images.unsplash.com/photo-1499750310107-5fef28a66643?w=1200&auto=format&fit=crop&q=80'
  );
  const [category, setCategory] = useState(post?.category || 'Design & Craft');
  const [tags, setTags] = useState<string[]>(post?.tags || ['Writing', 'Craft']);
  const [tagInput, setTagInput] = useState('');
  const [paywallType, setPaywallType] = useState<PaywallType>(post?.paywallType || 'free');
  const [isPremium, setIsPremium] = useState(post?.isPremium ?? false);
  const [premiumPrice, setPremiumPrice] = useState(post?.premiumPrice || 4.99);
  
  const [viewMode, setViewMode] = useState<'split' | 'edit' | 'preview'>('split');
  const [showSettings, setShowSettings] = useState(false);
  const [lastSaved, setLastSaved] = useState<string>('Just now');
  const [isSaving, setIsSaving] = useState(false);

  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Compute live statistics
  const wordCount = content.trim().split(/\s+/).filter(Boolean).length;
  const charCount = content.length;
  const readTime = Math.max(1, Math.ceil(wordCount / 200));

  // Preset cover images for quick selection
  const COVER_PRESETS = [
    { label: 'Minimal Desk', url: 'https://images.unsplash.com/photo-1499750310107-5fef28a66643?w=1200&auto=format&fit=crop&q=80' },
    { label: 'Code Matrix', url: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=1200&auto=format&fit=crop&q=80' },
    { label: 'Architecture', url: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?w=1200&auto=format&fit=crop&q=80' },
    { label: 'Atmospheric Fog', url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1200&auto=format&fit=crop&q=80' },
    { label: 'Library Vintage', url: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=1200&auto=format&fit=crop&q=80' },
    { label: 'Abstract Gradient', url: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=1200&auto=format&fit=crop&q=80' },
  ];

  // Formatting insert helpers
  const insertFormatting = (prefix: string, suffix: string = '', defaultPlaceholder: string = '') => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = content.substring(start, end) || defaultPlaceholder;

    const newContent = content.substring(0, start) + prefix + selectedText + suffix + content.substring(end);
    setContent(newContent);

    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(
        start + prefix.length,
        start + prefix.length + selectedText.length
      );
    }, 10);
  };

  const handleAddTag = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && tagInput.trim()) {
      e.preventDefault();
      const clean = tagInput.trim().replace(/^#/, '');
      if (!tags.includes(clean)) {
        setTags([...tags, clean]);
      }
      setTagInput('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter((t) => t !== tagToRemove));
  };

  const handleManualSave = (publish: boolean) => {
    setIsSaving(true);
    const postPayload: Partial<Post> = {
      id: post?.id || `post-${Date.now()}`,
      title: title || 'Untitled Story',
      subtitle: subtitle,
      content,
      coverImage,
      category,
      tags,
      wordCount,
      readTime,
      paywallType: isPremium ? paywallType : 'free',
      isPremium,
      premiumPrice: isPremium ? Number(premiumPrice) : 0,
      slug: (title || 'untitled-story').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
    };

    onSave(postPayload, publish);
    setTimeout(() => {
      setIsSaving(false);
      setLastSaved(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    }, 400);
  };

  const handleShareClick = () => {
    // Check if user has active premium subscription to share written content
    if (!currentUser.subscriptionActive) {
      onOpenPremiumModal();
    } else {
      const currentPostData: Post = {
        id: post?.id || `post-${Date.now()}`,
        title: title || 'Untitled Story',
        subtitle,
        slug: (title || 'untitled-story').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
        content,
        coverImage,
        tags,
        category,
        author: {
          id: currentUser.id,
          name: currentUser.name,
          handle: currentUser.handle,
          avatar: currentUser.avatar,
          bio: currentUser.bio,
          tier: currentUser.tier,
          followersCount: currentUser.followersCount,
          isVerified: true,
        },
        status: post?.status || 'published',
        publishedAt: post?.publishedAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        readTime,
        wordCount,
        isPremium,
        paywallType: isPremium ? paywallType : 'free',
        premiumPrice: isPremium ? Number(premiumPrice) : 0,
        claps: post?.claps || 0,
        bookmarksCount: post?.bookmarksCount || 0,
        viewsCount: post?.viewsCount || 0,
        readsCount: post?.readsCount || 0,
        commentsCount: post?.commentsCount || 0,
        sharesCount: post?.sharesCount || 0,
        allowComments: true,
      };
      onOpenShareModal(currentPostData);
    }
  };

  return (
    <div id="markdown-editor-container" className="min-h-[calc(100vh-4rem)] flex flex-col bg-neutral-50 text-neutral-900">
      
      {/* Top Studio Control Bar */}
      <div className="sticky top-16 z-30 flex items-center justify-between px-4 sm:px-6 py-2.5 bg-white border-b border-neutral-200 shadow-xs">
        
        {/* Back and Status */}
        <div className="flex items-center gap-3">
          <button
            id="editor-back-btn"
            onClick={onBackToFeed}
            className="p-1.5 text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 rounded-lg transition-colors"
            title="Back to feed"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-neutral-800 hidden sm:inline">
              Draft Studio
            </span>
            <span className="text-[11px] text-neutral-500 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              Autosaved {lastSaved}
            </span>
          </div>
        </div>

        {/* View Mode Switcher */}
        <div className="flex items-center bg-neutral-100 p-0.5 rounded-lg border border-neutral-200/80">
          <button
            id="view-mode-edit"
            onClick={() => setViewMode('edit')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs font-medium transition-all ${
              viewMode === 'edit'
                ? 'bg-white text-neutral-900 shadow-xs font-semibold'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
            title="Markdown Source Only"
          >
            <FileText className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Editor</span>
          </button>
          <button
            id="view-mode-split"
            onClick={() => setViewMode('split')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs font-medium transition-all ${
              viewMode === 'split'
                ? 'bg-white text-neutral-900 shadow-xs font-semibold'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
            title="Split Code & Preview"
          >
            <Columns className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Split</span>
          </button>
          <button
            id="view-mode-preview"
            onClick={() => setViewMode('preview')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs font-medium transition-all ${
              viewMode === 'preview'
                ? 'bg-white text-neutral-900 shadow-xs font-semibold'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
            title="Rendered Story Preview"
          >
            <Eye className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Preview</span>
          </button>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          {/* Settings Drawer Toggle */}
          <button
            id="toggle-story-settings-btn"
            onClick={() => setShowSettings(!showSettings)}
            className={`p-2 rounded-lg text-xs font-medium border transition-colors flex items-center gap-1.5 ${
              showSettings 
                ? 'bg-neutral-900 text-white border-neutral-900' 
                : 'bg-white text-neutral-700 border-neutral-200 hover:bg-neutral-50'
            }`}
            title="Story Settings & Paywall"
          >
            <Settings className="w-4 h-4" />
            <span className="hidden sm:inline">Settings</span>
          </button>

          {/* Share Content Button (Premium Gated!) */}
          <button
            id="share-story-action-btn"
            onClick={handleShareClick}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all shadow-xs ${
              currentUser.subscriptionActive
                ? 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-500/20'
                : 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white shadow-amber-500/20'
            }`}
            title="Share and syndicate your written content"
          >
            {currentUser.subscriptionActive ? (
              <>
                <Share2 className="w-3.5 h-3.5" />
                <span>Share Post</span>
              </>
            ) : (
              <>
                <Crown className="w-3.5 h-3.5" />
                <span>Share Post (Pro)</span>
              </>
            )}
          </button>

          {/* Publish / Save Button */}
          <button
            id="publish-story-btn"
            onClick={() => handleManualSave(true)}
            disabled={isSaving}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold shadow-xs transition-colors"
          >
            <Check className="w-3.5 h-3.5 text-emerald-400" />
            <span>{isSaving ? 'Publishing...' : 'Publish'}</span>
          </button>
        </div>

      </div>

      {/* Formatting Toolbar */}
      {viewMode !== 'preview' && (
        <div id="formatting-toolbar" className="flex items-center gap-1 px-4 sm:px-6 py-2 bg-neutral-100/90 border-b border-neutral-200 overflow-x-auto scrollbar-none text-neutral-700">
          <button
            onClick={() => insertFormatting('**', '**', 'bold text')}
            className="p-1.5 hover:bg-white hover:text-neutral-900 rounded transition-colors"
            title="Bold (Ctrl+B)"
          >
            <Bold className="w-4 h-4" />
          </button>
          <button
            onClick={() => insertFormatting('*', '*', 'italic text')}
            className="p-1.5 hover:bg-white hover:text-neutral-900 rounded transition-colors"
            title="Italic (Ctrl+I)"
          >
            <Italic className="w-4 h-4" />
          </button>
          <button
            onClick={() => insertFormatting('~~', '~~', 'strikethrough')}
            className="p-1.5 hover:bg-white hover:text-neutral-900 rounded transition-colors"
            title="Strikethrough"
          >
            <Strikethrough className="w-4 h-4" />
          </button>

          <div className="w-[1px] h-4 bg-neutral-300 mx-1" />

          <button
            onClick={() => insertFormatting('# ', '', 'Heading 1')}
            className="p-1.5 hover:bg-white hover:text-neutral-900 rounded transition-colors"
            title="Heading 1"
          >
            <Heading1 className="w-4 h-4" />
          </button>
          <button
            onClick={() => insertFormatting('## ', '', 'Heading 2')}
            className="p-1.5 hover:bg-white hover:text-neutral-900 rounded transition-colors"
            title="Heading 2"
          >
            <Heading2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => insertFormatting('### ', '', 'Heading 3')}
            className="p-1.5 hover:bg-white hover:text-neutral-900 rounded transition-colors"
            title="Heading 3"
          >
            <Heading3 className="w-4 h-4" />
          </button>

          <div className="w-[1px] h-4 bg-neutral-300 mx-1" />

          <button
            onClick={() => insertFormatting('> ', '', 'Quoted thought')}
            className="p-1.5 hover:bg-white hover:text-neutral-900 rounded transition-colors"
            title="Blockquote"
          >
            <Quote className="w-4 h-4" />
          </button>
          <button
            onClick={() => insertFormatting('`', '`', 'code')}
            className="p-1.5 hover:bg-white hover:text-neutral-900 rounded transition-colors"
            title="Inline Code"
          >
            <Code className="w-4 h-4" />
          </button>
          <button
            onClick={() => insertFormatting('```typescript\n', '\n```', '// Code snippet here')}
            className="p-1.5 hover:bg-white hover:text-neutral-900 rounded text-xs font-mono font-bold"
            title="Code Block"
          >
            &lt;/&gt;
          </button>

          <div className="w-[1px] h-4 bg-neutral-300 mx-1" />

          <button
            onClick={() => insertFormatting('- ', '', 'List item')}
            className="p-1.5 hover:bg-white hover:text-neutral-900 rounded transition-colors"
            title="Bullet List"
          >
            <List className="w-4 h-4" />
          </button>
          <button
            onClick={() => insertFormatting('1. ', '', 'Numbered item')}
            className="p-1.5 hover:bg-white hover:text-neutral-900 rounded transition-colors"
            title="Numbered List"
          >
            <ListOrdered className="w-4 h-4" />
          </button>
          <button
            onClick={() => insertFormatting('- [ ] ', '', 'Task item')}
            className="p-1.5 hover:bg-white hover:text-neutral-900 rounded transition-colors"
            title="Checklist"
          >
            <CheckSquare className="w-4 h-4" />
          </button>

          <div className="w-[1px] h-4 bg-neutral-300 mx-1" />

          <button
            onClick={() => insertFormatting('[', '](https://example.com)', 'link label')}
            className="p-1.5 hover:bg-white hover:text-neutral-900 rounded transition-colors"
            title="Insert Link"
          >
            <LinkIcon className="w-4 h-4" />
          </button>
          <button
            onClick={() => insertFormatting('![', '](https://images.unsplash.com/photo-1499750310107-5fef28a66643?w=1200)', 'Image Alt Text')}
            className="p-1.5 hover:bg-white hover:text-neutral-900 rounded transition-colors"
            title="Insert Image"
          >
            <ImageIcon className="w-4 h-4" />
          </button>
          <button
            onClick={() => insertFormatting('\n| Feature | Description |\n| :--- | :--- |\n| Fast | Instant sub-ms render |\n| Pure | Zero distraction |\n', '', '')}
            className="p-1.5 hover:bg-white hover:text-neutral-900 rounded transition-colors"
            title="Insert Markdown Table"
          >
            <TableIcon className="w-4 h-4" />
          </button>
          <button
            onClick={() => insertFormatting('\n---\n', '', '')}
            className="p-1.5 hover:bg-white hover:text-neutral-900 rounded transition-colors"
            title="Horizontal Divider"
          >
            <Minus className="w-4 h-4" />
          </button>

          {/* Quick Word Count & Reading Time stats on toolbar */}
          <div className="ml-auto hidden md:flex items-center gap-3 text-xs text-neutral-500 pr-2">
            <span><strong>{wordCount}</strong> words</span>
            <span>•</span>
            <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {readTime} min read</span>
          </div>
        </div>
      )}

      {/* Main Workspace with Split or Single Pane */}
      <div className="flex-1 flex overflow-hidden relative">
        
        {/* Left / Main Editor Pane */}
        {viewMode !== 'preview' && (
          <div className={`flex-1 flex flex-col bg-white overflow-y-auto ${
            viewMode === 'split' ? 'w-1/2 border-r border-neutral-200' : 'w-full max-w-4xl mx-auto'
          }`}>
            <div className="p-6 sm:p-10 space-y-4 max-w-3xl mx-auto w-full">
              
              {/* Title Input */}
              <input
                id="story-title-input"
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Story Title..."
                className="w-full text-2xl sm:text-4xl font-extrabold tracking-tight text-neutral-900 placeholder:text-neutral-300 border-none outline-none bg-transparent font-serif-custom focus:ring-0"
              />

              {/* Subtitle Input */}
              <input
                id="story-subtitle-input"
                type="text"
                value={subtitle}
                onChange={(e) => setSubtitle(e.target.value)}
                placeholder="Add a compelling subtitle or thesis summary..."
                className="w-full text-base sm:text-lg text-neutral-600 placeholder:text-neutral-300 border-none outline-none bg-transparent font-sans-custom focus:ring-0"
              />

              <div className="border-b border-neutral-100 pt-2" />

              {/* Markdown Content Area */}
              <textarea
                ref={textareaRef}
                id="story-markdown-textarea"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Write your story using markdown..."
                className="w-full min-h-[500px] resize-none font-mono text-sm leading-relaxed text-neutral-800 placeholder:text-neutral-300 border-none outline-none bg-transparent focus:ring-0"
              />
            </div>
          </div>
        )}

        {/* Right / Live Rendered Preview Pane */}
        {viewMode !== 'edit' && (
          <div className={`flex-1 bg-neutral-50 overflow-y-auto ${
            viewMode === 'split' ? 'w-1/2' : 'w-full max-w-4xl mx-auto'
          }`}>
            <div className="p-6 sm:p-10 max-w-3xl mx-auto">
              
              {/* Header Meta in Preview */}
              <div className="mb-6">
                <span className="inline-block px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-100 mb-3">
                  {category}
                </span>
                <h1 className="text-2xl sm:text-4xl font-bold font-serif-custom text-neutral-900 leading-tight">
                  {title || 'Untitled Story'}
                </h1>
                {subtitle && (
                  <p className="text-base sm:text-lg text-neutral-600 mt-2 font-sans-custom">
                    {subtitle}
                  </p>
                )}
                
                {/* Author card preview */}
                <div className="flex items-center gap-3 mt-4 pt-4 border-t border-neutral-200/60 text-xs text-neutral-500">
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.name}
                    className="w-7 h-7 rounded-full object-cover"
                  />
                  <div>
                    <span className="font-semibold text-neutral-800">{currentUser.name}</span>
                    <span className="mx-1.5">•</span>
                    <span>{readTime} min read</span>
                    <span className="mx-1.5">•</span>
                    <span>{wordCount} words</span>
                  </div>
                </div>
              </div>

              {/* Cover Image Preview */}
              {coverImage && (
                <div className="mb-8 rounded-xl overflow-hidden shadow-xs border border-neutral-200">
                  <img
                    src={coverImage}
                    alt="Cover preview"
                    className="w-full max-h-[320px] object-cover"
                  />
                </div>
              )}

              {/* Rendered Markdown Body */}
              <div className="markdown-body font-serif-custom text-neutral-800 text-base sm:text-lg">
                <ReactMarkdown remarkPlugins={[remarkGfm]}>
                  {content}
                </ReactMarkdown>
              </div>

              {/* Tags preview */}
              {tags.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mt-8 pt-6 border-t border-neutral-200">
                  {tags.map((t) => (
                    <span
                      key={t}
                      className="px-2.5 py-1 rounded-full text-xs bg-neutral-200/70 text-neutral-700 font-medium"
                    >
                      #{t}
                    </span>
                  ))}
                </div>
              )}

            </div>
          </div>
        )}

        {/* Story Settings Sidebar / Drawer */}
        {showSettings && (
          <div
            id="story-settings-drawer"
            className="absolute top-0 right-0 bottom-0 w-80 sm:w-96 bg-white border-l border-neutral-200 shadow-xl z-40 p-6 overflow-y-auto space-y-6"
          >
            <div className="flex items-center justify-between pb-3 border-b border-neutral-200">
              <h3 className="font-bold text-base text-neutral-900 flex items-center gap-2">
                <Settings className="w-4 h-4 text-indigo-600" />
                Story Settings & Distribution
              </h3>
              <button
                onClick={() => setShowSettings(false)}
                className="text-neutral-400 hover:text-neutral-600 text-sm font-bold"
              >
                ✕
              </button>
            </div>

            {/* Category */}
            <div>
              <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-2">
                Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full text-sm bg-neutral-50 border border-neutral-200 rounded-lg p-2.5 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
              >
                {CATEGORIES.filter(c => c !== 'All Stories').map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            {/* Cover Image Preset */}
            <div>
              <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-2">
                Cover Image URL
              </label>
              <input
                type="text"
                value={coverImage}
                onChange={(e) => setCoverImage(e.target.value)}
                placeholder="https://images.unsplash.com/..."
                className="w-full text-xs bg-neutral-50 border border-neutral-200 rounded-lg p-2.5 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none mb-2"
              />
              <span className="text-[11px] text-neutral-500 block mb-1.5">Quick curated presets:</span>
              <div className="grid grid-cols-3 gap-1.5">
                {COVER_PRESETS.map((preset) => (
                  <button
                    key={preset.label}
                    onClick={() => setCoverImage(preset.url)}
                    className={`text-[10px] p-1.5 rounded border text-center truncate ${
                      coverImage === preset.url
                        ? 'border-indigo-600 bg-indigo-50 text-indigo-700 font-semibold'
                        : 'border-neutral-200 bg-neutral-50 hover:bg-neutral-100 text-neutral-600'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Tags Input */}
            <div>
              <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-2">
                Tags (Press Enter to add)
              </label>
              <div className="flex flex-wrap gap-1.5 mb-2">
                {tags.map((t) => (
                  <span
                    key={t}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs bg-neutral-100 text-neutral-800 border border-neutral-200"
                  >
                    #{t}
                    <button
                      onClick={() => handleRemoveTag(t)}
                      className="text-neutral-400 hover:text-neutral-700 font-bold"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
              <input
                type="text"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={handleAddTag}
                placeholder="e.g. Design, Philosophy..."
                className="w-full text-xs bg-neutral-50 border border-neutral-200 rounded-lg p-2 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
              />
            </div>

            {/* Paywall & Monetization Settings */}
            <div className="pt-3 border-t border-neutral-200">
              <div className="flex items-center justify-between mb-3">
                <label className="text-xs font-bold text-neutral-700 uppercase tracking-wider flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-amber-600" />
                  Monetization & Paywall
                </label>
                <input
                  type="checkbox"
                  checked={isPremium}
                  onChange={(e) => setIsPremium(e.target.checked)}
                  className="w-4 h-4 accent-indigo-600 rounded cursor-pointer"
                />
              </div>

              {isPremium ? (
                <div className="space-y-3 bg-amber-50/60 p-3 rounded-lg border border-amber-200/80 text-xs">
                  <p className="text-amber-900 font-medium">
                    This story is gated for paid members or individual purchase.
                  </p>
                  <div>
                    <label className="block text-[11px] font-semibold text-neutral-700 mb-1">
                      Paywall Access Type:
                    </label>
                    <select
                      value={paywallType}
                      onChange={(e) => setPaywallType(e.target.value as PaywallType)}
                      className="w-full bg-white border border-amber-200 rounded p-1.5 text-xs font-medium"
                    >
                      <option value="premium_only">Subscribers Only (Full Paywall)</option>
                      <option value="metered">Metered Preview (Read 50% free)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-neutral-700 mb-1">
                      Standalone Story Price ($ USD):
                    </label>
                    <input
                      type="number"
                      step="0.50"
                      min="0.99"
                      max="49.99"
                      value={premiumPrice}
                      onChange={(e) => setPremiumPrice(parseFloat(e.target.value) || 0)}
                      className="w-full bg-white border border-amber-200 rounded p-1.5 text-xs font-medium"
                    />
                  </div>
                </div>
              ) : (
                <p className="text-xs text-neutral-500">
                  This story will be open and free for all public readers.
                </p>
              )}
            </div>

            {/* Sharing & Distribution Callout */}
            <div className="pt-3 border-t border-neutral-200">
              <div className="p-3 rounded-xl bg-gradient-to-br from-indigo-900 to-neutral-900 text-white space-y-2">
                <div className="flex items-center gap-1.5 text-amber-400 font-bold text-xs">
                  <Crown className="w-4 h-4" />
                  Premium Distribution
                </div>
                <p className="text-[11px] text-neutral-300 leading-relaxed">
                  Inkflow Writer Pro unlocks public vanity share links, social auto-cards, audience analytics, and newsletter syndication.
                </p>
                <button
                  onClick={handleShareClick}
                  className="w-full mt-2 py-1.5 px-3 rounded-lg text-xs font-bold bg-amber-400 hover:bg-amber-300 text-neutral-900 transition-colors flex items-center justify-center gap-1.5"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  {currentUser.subscriptionActive ? 'Manage Share Links' : 'Upgrade to Share Stories'}
                </button>
              </div>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
