import React, { useState } from 'react';
import { 
  Sparkles, 
  Crown, 
  Clock, 
  Share2, 
  Bookmark, 
  ArrowRight, 
  PenTool, 
  TrendingUp, 
  BookOpen, 
  Check, 
  Search,
  Filter,
  History,
  X,
  RotateCcw
} from 'lucide-react';
import { Post, UserProfile } from '../types';
import { CATEGORIES } from '../data/mockData';

interface ReaderFeedProps {
  posts: Post[];
  currentUser: UserProfile;
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
  searchQuery: string;
  recentlyReadIds?: string[];
  onClearRecentlyRead?: () => void;
  onRemoveRecentlyRead?: (id: string) => void;
  onSelectPost: (post: Post) => void;
  onOpenShareModal: (post: Post) => void;
  onOpenPremiumModal: () => void;
  onNewStory: () => void;
}

export const ReaderFeed: React.FC<ReaderFeedProps> = ({
  posts,
  currentUser,
  selectedCategory,
  onSelectCategory,
  searchQuery,
  recentlyReadIds = [],
  onClearRecentlyRead,
  onRemoveRecentlyRead,
  onSelectPost,
  onOpenShareModal,
  onOpenPremiumModal,
  onNewStory,
}) => {
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);

  const toggleBookmark = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (bookmarkedIds.includes(id)) {
      setBookmarkedIds(bookmarkedIds.filter((b) => b !== id));
    } else {
      setBookmarkedIds([...bookmarkedIds, id]);
    }
  };

  // Resolve recently read posts from tracked IDs
  const recentlyReadPosts = recentlyReadIds
    .map((id) => posts.find((p) => p.id === id))
    .filter((p): p is Post => Boolean(p));

  // Filter posts by category and search query
  const filteredPosts = posts.filter((post) => {
    const matchesCategory =
      selectedCategory === 'All Stories' || post.category === selectedCategory;
    const matchesSearch =
      !searchQuery ||
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.subtitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.author.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));

    return matchesCategory && matchesSearch;
  });

  const featuredPost = posts.find((p) => p.featured) || posts[0];
  const regularPosts = filteredPosts.filter((p) => p.id !== featuredPost?.id || selectedCategory !== 'All Stories' || searchQuery);

  return (
    <div id="reader-feed-container" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
      
      {/* Hero Welcome & Category Filters */}
      <div className="space-y-6">
        
        {/* Intro banner */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-2">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
              Curated Publication & Community
            </span>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-neutral-900 tracking-tight font-sans-custom mt-1">
              Thoughtful Writing for Curious Minds
            </h1>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onNewStory}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs sm:text-sm font-bold shadow-sm transition-all hover:scale-105"
            >
              <PenTool className="w-4 h-4" />
              <span>Write a Story</span>
            </button>
          </div>
        </div>

        {/* Categories Bar */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {CATEGORIES.map((cat) => {
            const count = cat === 'All Stories' ? posts.length : posts.filter(p => p.category === cat).length;
            const isSelected = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => onSelectCategory(cat)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-neutral-900 text-white shadow-xs'
                    : 'bg-white border border-neutral-200 text-neutral-600 hover:text-neutral-900 hover:border-neutral-300'
                }`}
              >
                <span>{cat}</span>
                {count > 0 && (
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                    isSelected ? 'bg-white/20 text-white' : 'bg-neutral-100 text-neutral-500'
                  }`}>
                    {count}
                  </span>
                )}
              </button>
            );
          })}
        </div>

      </div>

      {/* Featured Cover Story Banner (Only on All Stories without search query) */}
      {selectedCategory === 'All Stories' && !searchQuery && featuredPost && (
        <div
          onClick={() => onSelectPost(featuredPost)}
          className="group relative rounded-3xl overflow-hidden bg-neutral-900 text-white cursor-pointer shadow-xl border border-neutral-800 transition-all hover:shadow-2xl"
        >
          <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[380px]">
            
            {/* Left Content */}
            <div className="lg:col-span-7 p-6 sm:p-10 flex flex-col justify-between z-10">
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-400/20 text-amber-300 border border-amber-300/30">
                    Featured Editorial
                  </span>
                  {featuredPost.isPremium && (
                    <span className="flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-white/10 text-white border border-white/20">
                      <Crown className="w-3 h-3 text-amber-400" />
                      Premium
                    </span>
                  )}
                </div>

                <h2 className="text-2xl sm:text-4xl font-extrabold font-serif-custom tracking-tight group-hover:text-amber-200 transition-colors leading-tight">
                  {featuredPost.title}
                </h2>

                <p className="text-sm sm:text-base text-neutral-300 font-sans-custom line-clamp-3 leading-relaxed">
                  {featuredPost.subtitle}
                </p>
              </div>

              {/* Author and Action bar */}
              <div className="flex items-center justify-between pt-6 border-t border-neutral-800/80 mt-6 gap-4 flex-wrap">
                <div className="flex items-center gap-3">
                  <img
                    src={featuredPost.author.avatar}
                    alt={featuredPost.author.name}
                    className="w-10 h-10 rounded-full object-cover ring-2 ring-amber-400/40"
                  />
                  <div>
                    <p className="text-xs font-bold text-white">{featuredPost.author.name}</p>
                    <p className="text-[11px] text-neutral-400">
                      {featuredPost.readTime} min read • 👏 {featuredPost.claps}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenShareModal(featuredPost);
                    }}
                    className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold transition-colors flex items-center gap-1.5"
                    title="Share story"
                  >
                    <Share2 className="w-4 h-4" />
                    <span className="hidden sm:inline">Share</span>
                  </button>

                  <div className="flex items-center gap-1 text-xs font-bold text-amber-400 group-hover:translate-x-1 transition-transform">
                    <span>Read Story</span>
                    <ArrowRight className="w-4 h-4" />
                  </div>
                </div>
              </div>

            </div>

            {/* Right Image */}
            <div className="lg:col-span-5 relative overflow-hidden min-h-[220px] lg:min-h-full">
              <img
                src={featuredPost.coverImage}
                alt=""
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 opacity-85"
              />
              <div className="absolute inset-0 bg-gradient-to-t lg:bg-gradient-to-r from-neutral-900 via-neutral-900/30 to-transparent" />
            </div>

          </div>
        </div>
      )}

      {/* Recently Read Section (Synced with localStorage) */}
      {!searchQuery && recentlyReadPosts.length > 0 && (
        <section id="recently-read-section" className="space-y-4 pt-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-amber-500/10 text-amber-700 flex items-center justify-center border border-amber-200">
                <History className="w-4 h-4" />
              </div>
              <h3 className="font-bold text-lg text-neutral-900 font-sans-custom flex items-center gap-2">
                <span>Recently Read</span>
                <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-neutral-100 text-neutral-600">
                  {recentlyReadPosts.length}
                </span>
              </h3>
            </div>

            {onClearRecentlyRead && (
              <button
                id="clear-recently-read-btn"
                onClick={onClearRecentlyRead}
                className="flex items-center gap-1.5 text-xs text-neutral-500 hover:text-neutral-900 font-medium px-2.5 py-1 rounded-lg hover:bg-neutral-100 transition-colors"
                title="Clear your reading history"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Clear History</span>
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {recentlyReadPosts.slice(0, 4).map((post) => (
              <div
                key={`recent-${post.id}`}
                id={`recently-read-card-${post.id}`}
                onClick={() => onSelectPost(post)}
                className="group relative bg-white rounded-2xl border border-neutral-200 hover:border-neutral-300 p-4 shadow-2xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
              >
                <div className="space-y-3">
                  {/* Top Bar with Thumbnail & Dismiss */}
                  <div className="relative h-28 w-full rounded-xl overflow-hidden bg-neutral-100">
                    <img
                      src={post.coverImage}
                      alt=""
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                    
                    <div className="absolute top-2 left-2 flex items-center gap-1">
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-white/90 backdrop-blur-xs text-neutral-800 shadow-2xs">
                        {post.category}
                      </span>
                    </div>

                    {/* Individual remove button */}
                    {onRemoveRecentlyRead && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onRemoveRecentlyRead(post.id);
                        }}
                        className="absolute top-2 right-2 p-1 rounded-full bg-black/50 text-white/80 hover:text-white hover:bg-black/80 transition-colors"
                        title="Remove from history"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    )}

                    <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between text-[11px] text-white font-medium">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-amber-300" />
                        {post.readTime} min read
                      </span>
                      <span>👏 {post.claps}</span>
                    </div>
                  </div>

                  {/* Title & Subtitle */}
                  <div>
                    <h4 className="font-bold text-sm font-serif-custom text-neutral-900 group-hover:text-indigo-600 transition-colors line-clamp-2 leading-snug">
                      {post.title}
                    </h4>
                    <p className="text-[11px] text-neutral-500 line-clamp-1 mt-1">
                      {post.subtitle || post.author.name}
                    </p>
                  </div>
                </div>

                {/* Footer Author & Resume CTA */}
                <div className="pt-3 mt-3 border-t border-neutral-100 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 min-w-0">
                    <img
                      src={post.author.avatar}
                      alt=""
                      className="w-5 h-5 rounded-full object-cover shrink-0"
                    />
                    <span className="text-[11px] font-medium text-neutral-700 truncate">
                      {post.author.name}
                    </span>
                  </div>

                  <span className="text-[11px] font-bold text-indigo-600 group-hover:translate-x-0.5 transition-transform flex items-center gap-0.5">
                    <span>Resume</span>
                    <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Stories Grid */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-lg text-neutral-900 font-sans-custom flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-indigo-600" />
            <span>{selectedCategory === 'All Stories' ? 'Latest Stories' : selectedCategory}</span>
          </h3>
          <span className="text-xs text-neutral-500">
            {filteredPosts.length} {filteredPosts.length === 1 ? 'article' : 'articles'}
          </span>
        </div>

        {filteredPosts.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-2xl border border-neutral-200 space-y-3">
            <BookOpen className="w-12 h-12 text-neutral-300 mx-auto" />
            <h4 className="font-bold text-base text-neutral-800">No stories found</h4>
            <p className="text-xs text-neutral-500 max-w-sm mx-auto">
              We couldn't find any articles matching your search or category filter. Try clearing the filter or write your own piece.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPosts.map((post) => {
              const isBookmarked = bookmarkedIds.includes(post.id);
              return (
                <div
                  key={post.id}
                  onClick={() => onSelectPost(post)}
                  className="group bg-white rounded-2xl border border-neutral-200/80 hover:border-neutral-300 shadow-xs hover:shadow-md transition-all flex flex-col justify-between overflow-hidden cursor-pointer"
                >
                  <div>
                    {/* Cover Image */}
                    <div className="relative h-44 w-full overflow-hidden bg-neutral-100">
                      <img
                        src={post.coverImage}
                        alt=""
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      
                      {/* Badges on image */}
                      <div className="absolute top-3 left-3 flex items-center gap-1.5">
                        <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-white/90 backdrop-blur-xs text-neutral-900 shadow-xs">
                          {post.category}
                        </span>
                        {post.isPremium && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-amber-500 text-white shadow-xs">
                            <Crown className="w-3 h-3" />
                            Premium
                          </span>
                        )}
                      </div>

                      {/* Bookmark button */}
                      <button
                        onClick={(e) => toggleBookmark(post.id, e)}
                        className={`absolute top-3 right-3 p-1.5 rounded-full backdrop-blur-xs transition-colors ${
                          isBookmarked
                            ? 'bg-indigo-600 text-white'
                            : 'bg-white/80 text-neutral-700 hover:bg-white'
                        }`}
                        title="Bookmark"
                      >
                        <Bookmark className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Card Content */}
                    <div className="p-5 space-y-2">
                      <h3 className="font-bold text-lg font-serif-custom text-neutral-900 leading-snug group-hover:text-indigo-600 transition-colors line-clamp-2">
                        {post.title}
                      </h3>
                      <p className="text-xs text-neutral-600 font-sans-custom line-clamp-2 leading-relaxed">
                        {post.subtitle}
                      </p>
                    </div>
                  </div>

                  {/* Card Footer */}
                  <div className="px-5 pb-5 pt-2 border-t border-neutral-100 flex items-center justify-between text-xs text-neutral-500">
                    <div className="flex items-center gap-2">
                      <img
                        src={post.author.avatar}
                        alt=""
                        className="w-6 h-6 rounded-full object-cover"
                      />
                      <span className="font-medium text-neutral-800 truncate max-w-[100px]">
                        {post.author.name}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-[11px]">{post.readTime}m read</span>
                      <span>•</span>
                      <span>👏 {post.claps}</span>
                      
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenShareModal(post);
                        }}
                        className="p-1 hover:bg-neutral-100 rounded text-neutral-600 hover:text-neutral-900 transition-colors"
                        title="Share story"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                </div>
              );
            })}
          </div>
        )}

      </div>

      {/* Premium Sharing Callout Strip */}
      {!currentUser.subscriptionActive && (
        <div className="p-8 rounded-3xl bg-gradient-to-r from-amber-500/15 via-orange-500/10 to-indigo-500/15 border border-amber-300/80 flex flex-col md:flex-row items-center justify-between gap-6 shadow-sm">
          <div className="space-y-2 text-center md:text-left">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-800 text-xs font-bold uppercase tracking-wider">
              <Crown className="w-3.5 h-3.5 text-amber-600" />
              <span>Writer Pro Distribution Pass</span>
            </div>
            <h3 className="text-2xl font-extrabold text-neutral-900 font-sans-custom">
              Ready to Share Your Written Work?
            </h3>
            <p className="text-xs sm:text-sm text-neutral-600 max-w-xl leading-relaxed">
              Writer Pro allows you to publish public share links, distribute across newsletter subscribers, track live audience analytics, and collect subscription revenue.
            </p>
          </div>

          <button
            onClick={onOpenPremiumModal}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-bold text-xs sm:text-sm shadow-md shadow-amber-500/25 shrink-0 transition-all hover:scale-105 flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            <span>Unlock Sharing for $12/mo</span>
          </button>
        </div>
      )}

    </div>
  );
};
