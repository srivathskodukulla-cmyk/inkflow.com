import { useState } from 'react';
import { 
  Crown, 
  Check, 
  Sparkles, 
  Share2, 
  Globe, 
  BarChart3, 
  DollarSign, 
  Zap, 
  ShieldCheck, 
  X,
  CreditCard,
  Lock,
  Flame
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { PremiumTier, UserProfile } from '../types';

interface PremiumModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onUpgradeSuccess: (tier: PremiumTier) => void;
}

export const PremiumModal: React.FC<PremiumModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onUpgradeSuccess,
}) => {
  const [billingPeriod, setBillingPeriod] = useState<'monthly' | 'yearly'>('yearly');
  const [selectedPlan, setSelectedPlan] = useState<PremiumTier>('pro');
  const [isProcessing, setIsProcessing] = useState(false);
  const [showSuccessCard, setShowSuccessCard] = useState(false);

  if (!isOpen) return null;

  const triggerConfetti = () => {
    confetti({
      particleCount: 120,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#f59e0b', '#6366f1', '#10b981', '#ec4899']
    });
  };

  const handleCheckout = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setShowSuccessCard(true);
      triggerConfetti();
      onUpgradeSuccess(selectedPlan);
    }, 1200);
  };

  return (
    <div id="premium-paywall-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/70 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl border border-neutral-200 overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 z-20 p-2 text-neutral-400 hover:text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-full transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {showSuccessCard ? (
          /* Success Screen */
          <div className="p-10 text-center space-y-6 my-auto">
            <div className="w-16 h-16 bg-gradient-to-tr from-amber-400 to-orange-500 rounded-2xl flex items-center justify-center text-white mx-auto shadow-lg shadow-amber-500/30 animate-bounce">
              <Crown className="w-8 h-8" />
            </div>
            
            <div>
              <h2 className="text-2xl font-extrabold text-neutral-900 font-sans-custom">
                Welcome to Writer Pro! 
              </h2>
              <p className="text-sm text-neutral-600 mt-2 max-w-md mx-auto">
                Your account is now activated. You have unlocked unlimited public story sharing, custom vanity links, deep audience analytics, and paywall monetization.
              </p>
            </div>

            <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl max-w-md mx-auto text-left space-y-2 text-xs text-amber-900">
              <div className="flex items-center gap-2 font-bold text-amber-800">
                <Check className="w-4 h-4 text-emerald-600" />
                <span>Unlimited Public Story Sharing Unlocked</span>
              </div>
              <div className="flex items-center gap-2 font-bold text-amber-800">
                <Check className="w-4 h-4 text-emerald-600" />
                <span>Vanity URLs & Social Share Cards Active</span>
              </div>
              <div className="flex items-center gap-2 font-bold text-amber-800">
                <Check className="w-4 h-4 text-emerald-600" />
                <span>Audience Referrer Tracking Enabled</span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="px-8 py-3 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white font-bold text-sm shadow-md transition-all hover:scale-105"
            >
              Start Sharing Stories
            </button>
          </div>
        ) : (
          /* Pricing & Upgrade Selection Screen */
          <div className="overflow-y-auto p-6 sm:p-8 space-y-6">
            
            {/* Header */}
            <div className="text-center max-w-lg mx-auto space-y-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-xs font-bold uppercase tracking-wider">
                <Flame className="w-3.5 h-3.5 text-amber-600 fill-amber-500" />
                <span>Premium Distribution Tier</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 tracking-tight font-sans-custom">
                Share Your Written Content with the World
              </h2>
              <p className="text-xs sm:text-sm text-neutral-600 leading-relaxed">
                Writing is free for all creators. To share your published work, generate public vanity links, syndicate across channels, and monetize your audience, upgrade to <strong className="text-neutral-900">Writer Pro</strong>.
              </p>
            </div>

            {/* Billing Switcher */}
            <div className="flex items-center justify-center">
              <div className="flex items-center bg-neutral-100 p-1 rounded-full border border-neutral-200 text-xs font-semibold">
                <button
                  onClick={() => setBillingPeriod('monthly')}
                  className={`px-4 py-1.5 rounded-full transition-all ${
                    billingPeriod === 'monthly'
                      ? 'bg-white text-neutral-900 shadow-xs'
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                >
                  Monthly Billing
                </button>
                <button
                  onClick={() => setBillingPeriod('yearly')}
                  className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full transition-all ${
                    billingPeriod === 'yearly'
                      ? 'bg-white text-neutral-900 shadow-xs'
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                >
                  <span>Annual Billing</span>
                  <span className="px-1.5 py-0.2 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                    Save 30%
                  </span>
                </button>
              </div>
            </div>

            {/* Pricing Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              
              {/* Writer Pro (Recommended) */}
              <div 
                onClick={() => setSelectedPlan('pro')}
                className={`relative p-6 rounded-2xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                  selectedPlan === 'pro'
                    ? 'border-amber-500 bg-amber-50/20 shadow-md ring-2 ring-amber-400/20'
                    : 'border-neutral-200 hover:border-neutral-300 bg-white'
                }`}
              >
                <div className="absolute -top-3 right-6 px-3 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 text-white text-[10px] font-extrabold uppercase tracking-wider shadow-xs">
                  Most Popular
                </div>

                <div>
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-extrabold text-lg text-neutral-900 flex items-center gap-1.5">
                        <Crown className="w-4 h-4 text-amber-600" />
                        Writer Pro
                      </h3>
                      <p className="text-xs text-neutral-500">For authors ready to share & grow</p>
                    </div>
                  </div>

                  <div className="mt-4 mb-5 flex items-baseline gap-1">
                    <span className="text-3xl font-extrabold text-neutral-900">
                      {billingPeriod === 'yearly' ? '$8' : '$12'}
                    </span>
                    <span className="text-xs text-neutral-500 font-medium">/ month, billed {billingPeriod}</span>
                  </div>

                  <ul className="space-y-2.5 text-xs text-neutral-700">
                    <li className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span><strong>Unlimited Story Sharing:</strong> Generate public shareable links</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span><strong>Vanity URLs:</strong> <code className="font-mono bg-neutral-100 px-1 py-0.5 rounded">inkflow.co/s/your-title</code></span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span><strong>Social Share Cards:</strong> Auto-generated rich previews</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span><strong>Audience Analytics:</strong> Live views, reads, & referrers</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span><strong>Paywall Monetization:</strong> Keep 95% of reader subscriptions</span>
                    </li>
                  </ul>
                </div>

                <div className="mt-6 pt-4 border-t border-neutral-100 flex items-center justify-between text-xs font-semibold text-amber-800">
                  <span>Included Share Pass</span>
                  <span>Instant Activation</span>
                </div>
              </div>

              {/* Writer Studio */}
              <div 
                onClick={() => setSelectedPlan('studio')}
                className={`p-6 rounded-2xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                  selectedPlan === 'studio'
                    ? 'border-indigo-600 bg-indigo-50/20 shadow-md ring-2 ring-indigo-500/20'
                    : 'border-neutral-200 hover:border-neutral-300 bg-white'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-extrabold text-lg text-neutral-900 flex items-center gap-1.5">
                        <Sparkles className="w-4 h-4 text-indigo-600" />
                        Writer Studio
                      </h3>
                      <p className="text-xs text-neutral-500">For publications & high-volume creators</p>
                    </div>
                  </div>

                  <div className="mt-4 mb-5 flex items-baseline gap-1">
                    <span className="text-3xl font-extrabold text-neutral-900">
                      {billingPeriod === 'yearly' ? '$20' : '$29'}
                    </span>
                    <span className="text-xs text-neutral-500 font-medium">/ month, billed {billingPeriod}</span>
                  </div>

                  <ul className="space-y-2.5 text-xs text-neutral-700">
                    <li className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                      <span><strong>Everything in Pro</strong></span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                      <span><strong>Custom Domain:</strong> <code className="font-mono bg-neutral-100 px-1 py-0.5 rounded">stories.yourbrand.com</code></span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                      <span><strong>Editorial Team:</strong> Up to 5 co-authors & reviewers</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                      <span><strong>Newsletter Broadcasts:</strong> Deliver stories to 50k emails</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                      <span><strong>Priority Feed Placement:</strong> Featured in explore</span>
                    </li>
                  </ul>
                </div>

                <div className="mt-6 pt-4 border-t border-neutral-100 flex items-center justify-between text-xs font-semibold text-indigo-800">
                  <span>Full Publication Suite</span>
                  <span>White Label</span>
                </div>
              </div>

            </div>

            {/* Instant Checkout Button */}
            <div className="space-y-3 pt-2">
              <button
                id="confirm-upgrade-checkout-btn"
                onClick={handleCheckout}
                disabled={isProcessing}
                className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-600 hover:to-orange-700 text-white font-bold text-sm shadow-lg shadow-amber-500/25 transition-all hover:scale-[1.01] active:scale-[0.99] flex items-center justify-center gap-2"
              >
                {isProcessing ? (
                  <span>Activating Your Share Pass...</span>
                ) : (
                  <>
                    <CreditCard className="w-4 h-4" />
                    <span>
                      Upgrade & Unlock Story Sharing ({selectedPlan === 'pro' ? 'Writer Pro' : 'Writer Studio'})
                    </span>
                  </>
                )}
              </button>

              <div className="flex items-center justify-center gap-4 text-[11px] text-neutral-500">
                <span className="flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  Instant Activation
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Lock className="w-3.5 h-3.5 text-neutral-400" />
                  Cancel Anytime
                </span>
                <span>•</span>
                <span>30-Day Money-Back Guarantee</span>
              </div>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
