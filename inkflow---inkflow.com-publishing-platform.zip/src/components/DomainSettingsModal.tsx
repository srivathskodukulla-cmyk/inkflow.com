import React, { useState } from 'react';
import { 
  X, 
  Globe, 
  Check, 
  Copy, 
  ShieldCheck, 
  ArrowUpRight, 
  RefreshCw, 
  CheckCircle2, 
  Server, 
  Lock, 
  ExternalLink,
  HelpCircle,
  AlertCircle
} from 'lucide-react';

interface DomainSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DomainSettingsModal: React.FC<DomainSettingsModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [verifiedSuccess, setVerifiedSuccess] = useState(true);

  if (!isOpen) return null;

  const handleCopy = (key: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleRecheck = () => {
    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      setVerifiedSuccess(true);
    }, 1200);
  };

  const dnsRecords = [
    {
      type: 'A',
      host: '@',
      value: '216.239.32.21',
      ttl: '3600 (1 hour)',
      status: 'Configured',
      description: 'Apex domain routing (IPv4)',
    },
    {
      type: 'A',
      host: '@',
      value: '216.239.34.21',
      ttl: '3600 (1 hour)',
      status: 'Configured',
      description: 'Secondary failover anycast IP',
    },
    {
      type: 'CNAME',
      host: 'www',
      value: 'ghs.googlehosted.com',
      ttl: '3600 (1 hour)',
      status: 'Configured',
      description: 'WWW subdomain mapping',
    },
    {
      type: 'TXT',
      host: '@',
      value: 'inkflow-verify-site=9265b9f7-2671-46f1-9827-edd74673e475',
      ttl: '300 (5 mins)',
      status: 'Verified',
      description: 'Ownership & SSL validation token',
    },
  ];

  return (
    <div id="domain-settings-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/70 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-neutral-200 overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-neutral-200 bg-neutral-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-600 to-violet-600 flex items-center justify-center text-white shadow-sm shadow-indigo-500/20">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-lg text-neutral-900 font-sans-custom">
                  Custom Domain: inkflow.com
                </h3>
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  Primary Host
                </span>
              </div>
              <p className="text-xs text-neutral-500 mt-0.5">
                Manage DNS records, SSL/TLS certificates, and canonical routing for inkflow.com
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-neutral-700 bg-white hover:bg-neutral-100 rounded-full border border-neutral-200 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          
          {/* Domain Status Banner */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-indigo-500/10 border border-emerald-300/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-neutral-900">
                  Domain & SSL Security Active
                </h4>
                <p className="text-xs text-neutral-600">
                  Canonical URL: <code className="font-mono text-neutral-800 font-bold bg-white/70 px-1 py-0.5 rounded border border-neutral-200">https://inkflow.com</code>
                </p>
              </div>
            </div>

            <button
              onClick={handleRecheck}
              disabled={isVerifying}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-neutral-200 hover:bg-neutral-50 text-neutral-700 text-xs font-semibold shadow-2xs transition-all disabled:opacity-60"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isVerifying ? 'animate-spin text-indigo-600' : ''}`} />
              <span>{isVerifying ? 'Checking DNS...' : 'Verify DNS'}</span>
            </button>
          </div>

          {/* Configuration Guide */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-700">
                Required DNS Records (Your Domain Registrar)
              </h4>
              <span className="text-[11px] text-neutral-400">
                Cloudflare • Namecheap • GoDaddy • Google Domains
              </span>
            </div>

            <div className="border border-neutral-200 rounded-2xl overflow-hidden shadow-2xs">
              <table className="w-full text-left text-xs">
                <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-500 font-bold">
                  <tr>
                    <th className="py-2.5 px-3.5">Type</th>
                    <th className="py-2.5 px-3.5">Host / Name</th>
                    <th className="py-2.5 px-3.5">Value / Target</th>
                    <th className="py-2.5 px-3.5">TTL</th>
                    <th className="py-2.5 px-3.5 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-200 font-mono text-[11px]">
                  {dnsRecords.map((rec, idx) => (
                    <tr key={idx} className="hover:bg-neutral-50/80 transition-colors">
                      <td className="py-2.5 px-3.5 font-bold text-indigo-600 font-sans">
                        <span className="px-1.5 py-0.5 bg-indigo-50 border border-indigo-100 rounded text-[10px]">
                          {rec.type}
                        </span>
                      </td>
                      <td className="py-2.5 px-3.5 font-semibold text-neutral-800">{rec.host}</td>
                      <td className="py-2.5 px-3.5 text-neutral-700 truncate max-w-[180px] sm:max-w-xs" title={rec.value}>
                        {rec.value}
                      </td>
                      <td className="py-2.5 px-3.5 text-neutral-500 font-sans">{rec.ttl}</td>
                      <td className="py-2.5 px-3.5 text-right">
                        <button
                          onClick={() => handleCopy(`dns-${idx}`, rec.value)}
                          className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-neutral-100 hover:bg-neutral-200 text-neutral-700 text-[10px] font-sans font-semibold transition-colors"
                        >
                          {copiedKey === `dns-${idx}` ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-600" />
                              <span className="text-emerald-700">Copied</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span>Copy</span>
                            </>
                          )}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Hosting Architecture Summary */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3.5 rounded-xl bg-neutral-50 border border-neutral-200 space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400">Target Host</span>
              <p className="text-xs font-bold text-neutral-900 font-mono">inkflow.com</p>
              <p className="text-[11px] text-neutral-500">Auto-redirects HTTP &rarr; HTTPS</p>
            </div>

            <div className="p-3.5 rounded-xl bg-neutral-50 border border-neutral-200 space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400">SSL Certificate</span>
              <p className="text-xs font-bold text-emerald-600 flex items-center gap-1">
                <Lock className="w-3 h-3" />
                TLS 1.3 Managed
              </p>
              <p className="text-[11px] text-neutral-500">Auto-renewing certificate</p>
            </div>

            <div className="p-3.5 rounded-xl bg-neutral-50 border border-neutral-200 space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400">CDN & Edge Cache</span>
              <p className="text-xs font-bold text-indigo-600 flex items-center gap-1">
                <Server className="w-3 h-3" />
                Global Anycast
              </p>
              <p className="text-[11px] text-neutral-500">&lt; 35ms edge latency</p>
            </div>
          </div>

          {/* Instructions Box */}
          <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-600 space-y-2">
            <div className="flex items-center gap-2 font-bold text-neutral-900">
              <HelpCircle className="w-4 h-4 text-indigo-600" />
              <span>How custom domain routing works for inkflow.com:</span>
            </div>
            <ol className="list-decimal list-inside space-y-1 text-neutral-600 pl-1">
              <li>Open your domain registrar (e.g. Cloudflare, Namecheap, Google Cloud DNS).</li>
              <li>Add the <strong>A</strong> and <strong>CNAME</strong> records from the table above.</li>
              <li>Add the <strong>TXT</strong> ownership verification record.</li>
              <li>DNS updates will propagate worldwide within 5 to 60 minutes.</li>
            </ol>
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-200 bg-neutral-50 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-neutral-500">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>Ready for production traffic on <strong>inkflow.com</strong></span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-bold shadow-xs transition-colors"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
};
