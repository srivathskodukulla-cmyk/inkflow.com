import { useState } from 'react';
import { 
  X, 
  Copy, 
  Check, 
  Share2, 
  Crown, 
  Lock, 
  Sparkles, 
  QrCode, 
  Code2, 
  ExternalLink,
  Twitter,
  Linkedin,
  Mail,
  MessageSquare,
  Shield,
  Gift
} from 'lucide-react';
import { Post, UserProfile } from '../types';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  post: Post | null;
  currentUser: UserProfile;
  onOpenPremiumModal: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  isOpen,
  onClose,
  post,
  currentUser,
  onOpenPremiumModal,
}) => {
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'link' | 'social' | 'embed' | 'qr'>('link');
  const [giftPassEnabled, setGiftPassEnabled] = useState(false);

  if (!isOpen || !post) return null;

  const shareUrl = `https://inkflow.com/s/${post.customShareSlug || post.slug || post.id}${giftPassEnabled ? '?pass=vip_free' : ''}`;
  const embedCode = `<iframe src="https://inkflow.com/embed/${post.slug}" width="100%" height="450" frameborder="0" title="${post.title}"></iframe>`;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSocialShare = (platform: 'twitter' | 'linkedin' | 'email') => {
    const text = encodeURIComponent(`"${post.title}" by ${post.author.name} on @Inkflow`);
    const url = encodeURIComponent(shareUrl);

    if (platform === 'twitter') {
      window.open(`https://twitter.com/intent/tweet?text=${text}&url=${url}`, '_blank');
    } else if (platform === 'linkedin') {
      window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${url}`, '_blank');
    } else if (platform === 'email') {
      window.open(`mailto:?subject=${encodeURIComponent(post.title)}&body=${text}%0A%0ARead here: ${url}`, '_blank');
    }
  };

  return (
    <div id="share-content-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/70 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-neutral-200 overflow-hidden flex flex-col">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between p-5 border-b border-neutral-200 bg-neutral-50/50">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600">
              <Share2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base text-neutral-900">
                Share & Distribute Story
              </h3>
              <p className="text-xs text-neutral-500 truncate max-w-xs sm:max-w-sm">
                {post.title}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-neutral-700 bg-white hover:bg-neutral-100 rounded-full border border-neutral-200 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Check if User is Premium to Share Written Content */}
        {!currentUser.subscriptionActive ? (
          /* Locked Premium State for Non-Subscribers */
          <div className="p-6 sm:p-8 text-center space-y-5">
            <div className="w-14 h-14 bg-gradient-to-tr from-amber-500 to-orange-500 rounded-2xl flex items-center justify-center text-white mx-auto shadow-md shadow-amber-500/25">
              <Lock className="w-7 h-7" />
            </div>

            <div className="space-y-2">
              <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200 text-xs font-bold uppercase tracking-wider">
                <Crown className="w-3.5 h-3.5 text-amber-600" />
                <span>Premium Feature</span>
              </div>
              <h4 className="text-xl font-extrabold text-neutral-900 font-sans-custom">
                Story Sharing Requires Writer Pro
              </h4>
              <p className="text-xs sm:text-sm text-neutral-600 max-w-md mx-auto leading-relaxed">
                To distribute your written content to readers, generate public vanity links, syndicate across social networks, and track audience referrals, upgrade to <strong className="text-neutral-900">Writer Pro</strong>.
              </p>
            </div>

            <div className="p-4 bg-neutral-50 rounded-2xl border border-neutral-200/80 text-left space-y-2 max-w-md mx-auto text-xs text-neutral-700">
              <p className="font-bold text-neutral-900 mb-1">What you unlock with Writer Pro:</p>
              <div className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span>Public shareable vanity links (<code className="bg-white px-1 py-0.5 rounded border">inkflow.com/s/...</code>)</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span>Real-time audience tracking & referral analytics</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span>One-click social card syndication (X, LinkedIn)</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span>Gated paywall monetization to earn subscription income</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <button
                onClick={onClose}
                className="flex-1 py-2.5 px-4 rounded-xl border border-neutral-200 text-neutral-700 text-xs font-semibold hover:bg-neutral-50 transition-colors"
              >
                Keep as Local Draft
              </button>
              <button
                id="unlock-sharing-from-modal-btn"
                onClick={() => {
                  onClose();
                  onOpenPremiumModal();
                }}
                className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white text-xs font-bold shadow-md shadow-amber-500/25 transition-all hover:scale-105 flex items-center justify-center gap-1.5"
              >
                <Sparkles className="w-4 h-4" />
                <span>Unlock Sharing with Pro ($12)</span>
              </button>
            </div>
          </div>
        ) : (
          /* Unlocked Premium Sharing Suite for Subscribers */
          <div className="p-6 space-y-5">
            
            {/* Tabs */}
            <div className="flex items-center border-b border-neutral-200 text-xs font-semibold text-neutral-600">
              <button
                onClick={() => setActiveTab('link')}
                className={`pb-2.5 px-3 border-b-2 transition-all ${
                  activeTab === 'link' ? 'border-indigo-600 text-indigo-600 font-bold' : 'border-transparent hover:text-neutral-900'
                }`}
              >
                Vanity Link
              </button>
              <button
                onClick={() => setActiveTab('social')}
                className={`pb-2.5 px-3 border-b-2 transition-all ${
                  activeTab === 'social' ? 'border-indigo-600 text-indigo-600 font-bold' : 'border-transparent hover:text-neutral-900'
                }`}
              >
                Social Syndication
              </button>
              <button
                onClick={() => setActiveTab('qr')}
                className={`pb-2.5 px-3 border-b-2 transition-all ${
                  activeTab === 'qr' ? 'border-indigo-600 text-indigo-600 font-bold' : 'border-transparent hover:text-neutral-900'
                }`}
              >
                QR Code Pass
              </button>
              <button
                onClick={() => setActiveTab('embed')}
                className={`pb-2.5 px-3 border-b-2 transition-all ${
                  activeTab === 'embed' ? 'border-indigo-600 text-indigo-600 font-bold' : 'border-transparent hover:text-neutral-900'
                }`}
              >
                Embed Snippet
              </button>
            </div>

            {/* Vanity Link Tab */}
            {activeTab === 'link' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-2">
                    Public Share URL (Writer Pro Verified)
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      readOnly
                      value={shareUrl}
                      className="flex-1 text-xs font-mono bg-neutral-50 border border-neutral-200 rounded-xl px-3 py-2.5 text-neutral-800 select-all outline-none"
                    />
                    <button
                      onClick={() => handleCopy(shareUrl)}
                      className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
                        copied
                          ? 'bg-emerald-600 text-white'
                          : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs'
                      }`}
                    >
                      {copied ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* VIP Gift Pass Toggle */}
                <div className="p-3.5 rounded-xl bg-indigo-50/60 border border-indigo-100 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <Gift className="w-4 h-4 text-indigo-600" />
                    <div>
                      <p className="text-xs font-bold text-neutral-900">VIP Friend Gift Link</p>
                      <p className="text-[11px] text-neutral-500">Allow recipient to bypass the paywall without paying</p>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={giftPassEnabled}
                    onChange={(e) => setGiftPassEnabled(e.target.checked)}
                    className="w-4 h-4 accent-indigo-600 rounded cursor-pointer"
                  />
                </div>

                {/* Attribution info */}
                <div className="flex items-center justify-between text-[11px] text-neutral-500 pt-1">
                  <span className="flex items-center gap-1">
                    <Shield className="w-3 h-3 text-emerald-600" />
                    Real-time referrer analytics enabled
                  </span>
                  <span>{post.sharesCount} total shares recorded</span>
                </div>
              </div>
            )}

            {/* Social Syndication Tab */}
            {activeTab === 'social' && (
              <div className="space-y-4">
                <p className="text-xs text-neutral-600">
                  Broadcast this story directly to your social followers with customized previews:
                </p>
                <div className="grid grid-cols-3 gap-3">
                  <button
                    onClick={() => handleSocialShare('twitter')}
                    className="p-3 rounded-xl border border-neutral-200 bg-neutral-50 hover:bg-neutral-100 text-neutral-900 text-xs font-bold flex flex-col items-center gap-1.5 transition-colors"
                  >
                    <Twitter className="w-5 h-5 text-sky-500" />
                    <span>X / Twitter</span>
                  </button>
                  <button
                    onClick={() => handleSocialShare('linkedin')}
                    className="p-3 rounded-xl border border-neutral-200 bg-neutral-50 hover:bg-neutral-100 text-neutral-900 text-xs font-bold flex flex-col items-center gap-1.5 transition-colors"
                  >
                    <Linkedin className="w-5 h-5 text-blue-600" />
                    <span>LinkedIn</span>
                  </button>
                  <button
                    onClick={() => handleSocialShare('email')}
                    className="p-3 rounded-xl border border-neutral-200 bg-neutral-50 hover:bg-neutral-100 text-neutral-900 text-xs font-bold flex flex-col items-center gap-1.5 transition-colors"
                  >
                    <Mail className="w-5 h-5 text-neutral-700" />
                    <span>Newsletter / Email</span>
                  </button>
                </div>
              </div>
            )}

            {/* QR Code Tab */}
            {activeTab === 'qr' && (
              <div className="text-center space-y-3 py-2">
                <div className="w-36 h-36 bg-neutral-100 border-2 border-dashed border-neutral-300 rounded-2xl flex flex-col items-center justify-center mx-auto text-neutral-700">
                  <QrCode className="w-16 h-16 text-indigo-600" />
                  <span className="text-[10px] font-mono mt-1 font-bold">INKFLOW-QR-PASS</span>
                </div>
                <p className="text-xs text-neutral-600">
                  Scan to read instantly on mobile or print for your reading club / conference talk.
                </p>
              </div>
            )}

            {/* Embed Tab */}
            {activeTab === 'embed' && (
              <div className="space-y-2">
                <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider">
                  HTML Embed Code
                </label>
                <textarea
                  readOnly
                  value={embedCode}
                  className="w-full text-xs font-mono bg-neutral-50 border border-neutral-200 rounded-xl p-3 text-neutral-700 select-all outline-none resize-none h-24"
                />
                <button
                  onClick={() => handleCopy(embedCode)}
                  className="w-full py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold transition-colors"
                >
                  Copy Embed Code
                </button>
              </div>
            )}

          </div>
        )}

      </div>
    </div>
  );
};
