import { useState } from 'react';
import { 
  TrendingUp, 
  Users, 
  Eye, 
  BookOpen, 
  Share2, 
  DollarSign, 
  Clock, 
  ArrowUpRight, 
  Download, 
  Sparkles, 
  Globe, 
  Smartphone, 
  Laptop, 
  ExternalLink,
  ChevronRight,
  Filter,
  BarChart2,
  Crown
} from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  Legend
} from 'recharts';
import { AudienceAnalyticsData, Post, UserProfile } from '../types';

interface AudienceAnalyticsProps {
  analytics: AudienceAnalyticsData;
  posts: Post[];
  currentUser: UserProfile;
  onOpenPremiumModal: () => void;
  onSelectPost: (post: Post) => void;
}

export const AudienceAnalytics: React.FC<AudienceAnalyticsProps> = ({
  analytics,
  posts,
  currentUser,
  onOpenPremiumModal,
  onSelectPost,
}) => {
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d' | 'all'>('30d');
  const [activeMetricTab, setActiveMetricTab] = useState<'views' | 'reads' | 'shares' | 'earnings'>('views');

  // Filter timeline based on timeRange
  const displayTimeline = timeRange === '7d' 
    ? analytics.timeline.slice(-4) 
    : analytics.timeline;

  const handleExportData = () => {
    const csvContent = "data:text/csv;charset=utf-8," 
      + "Date,Views,Reads,Visitors,Shares,Earnings\n"
      + analytics.timeline.map(e => `${e.date},${e.views},${e.reads},${e.visitors},${e.shares},${e.earnings}`).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `inkflow_audience_analytics_${timeRange}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div id="audience-analytics-page" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-neutral-200">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-neutral-900 font-sans-custom">
              Audience Analytics & Reach
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
              Live Real-Time
            </span>
          </div>
          <p className="text-sm text-neutral-600 mt-1">
            Track your readership growth, engagement velocity, and premium content performance.
          </p>
        </div>

        {/* Filters & Export */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Time Range Selector */}
          <div className="flex items-center bg-neutral-100 p-1 rounded-xl border border-neutral-200">
            <button
              onClick={() => setTimeRange('7d')}
              className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all ${
                timeRange === '7d' ? 'bg-white text-neutral-900 shadow-xs' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              7 Days
            </button>
            <button
              onClick={() => setTimeRange('30d')}
              className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all ${
                timeRange === '30d' ? 'bg-white text-neutral-900 shadow-xs' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              30 Days
            </button>
            <button
              onClick={() => setTimeRange('90d')}
              className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all ${
                timeRange === '90d' ? 'bg-white text-neutral-900 shadow-xs' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              90 Days
            </button>
            <button
              onClick={() => setTimeRange('all')}
              className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all ${
                timeRange === 'all' ? 'bg-white text-neutral-900 shadow-xs' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              All Time
            </button>
          </div>

          {/* Export Report */}
          <button
            onClick={handleExportData}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl border border-neutral-200 bg-white hover:bg-neutral-50 text-xs font-semibold text-neutral-700 shadow-xs transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Premium Sharing Banner if user is free */}
      {!currentUser.subscriptionActive && (
        <div className="p-5 rounded-2xl bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-indigo-500/10 border border-amber-300/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-xs">
          <div className="flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-500 text-white flex items-center justify-center shrink-0 shadow-sm shadow-amber-500/20">
              <Crown className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-neutral-900 flex items-center gap-2">
                Unlock Direct Story Sharing & Custom Attribution Links
              </h3>
              <p className="text-xs text-neutral-600 mt-0.5">
                Writer Pro members unlock custom vanity links (<code className="font-mono text-[11px] bg-white/80 px-1 py-0.5 rounded border border-neutral-200">inkflow.co/s/your-title</code>), cross-network tracking, and deep referrer metrics.
              </p>
            </div>
          </div>
          <button
            onClick={onOpenPremiumModal}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white text-xs font-bold shadow-sm shadow-amber-500/25 shrink-0 transition-all hover:scale-105"
          >
            Upgrade to Pro ($12/mo)
          </button>
        </div>
      )}

      {/* Top 5 Metric KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        
        {/* Total Views */}
        <div 
          onClick={() => setActiveMetricTab('views')}
          className={`p-5 rounded-2xl border transition-all cursor-pointer ${
            activeMetricTab === 'views' 
              ? 'bg-indigo-50/50 border-indigo-300 shadow-sm ring-1 ring-indigo-500/20' 
              : 'bg-white border-neutral-200/80 hover:border-neutral-300'
          }`}
        >
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-600">Total Views</span>
            <div className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600">
              <Eye className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-neutral-900 tracking-tight">
            {analytics.overview.totalViews.toLocaleString()}
          </div>
          <div className="flex items-center gap-1.5 mt-2 text-xs font-semibold text-emerald-600">
            <ArrowUpRight className="w-3.5 h-3.5" />
            <span>+{analytics.overview.viewsGrowth}% vs last period</span>
          </div>
        </div>

        {/* Total Reads */}
        <div 
          onClick={() => setActiveMetricTab('reads')}
          className={`p-5 rounded-2xl border transition-all cursor-pointer ${
            activeMetricTab === 'reads' 
              ? 'bg-indigo-50/50 border-indigo-300 shadow-sm ring-1 ring-indigo-500/20' 
              : 'bg-white border-neutral-200/80 hover:border-neutral-300'
          }`}
        >
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-600">Total Reads</span>
            <div className="p-1.5 rounded-lg bg-blue-50 text-blue-600">
              <BookOpen className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-neutral-900 tracking-tight">
            {analytics.overview.totalReads.toLocaleString()}
          </div>
          <div className="flex items-center gap-1.5 mt-2 text-xs text-neutral-600">
            <span className="font-bold text-neutral-900">{analytics.overview.avgReadRatio}%</span>
            <span>completion ratio</span>
          </div>
        </div>

        {/* Shares & Amplification */}
        <div 
          onClick={() => setActiveMetricTab('shares')}
          className={`p-5 rounded-2xl border transition-all cursor-pointer ${
            activeMetricTab === 'shares' 
              ? 'bg-indigo-50/50 border-indigo-300 shadow-sm ring-1 ring-indigo-500/20' 
              : 'bg-white border-neutral-200/80 hover:border-neutral-300'
          }`}
        >
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-600">Story Shares</span>
            <div className="p-1.5 rounded-lg bg-violet-50 text-violet-600">
              <Share2 className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-neutral-900 tracking-tight">
            {analytics.overview.totalShares}
          </div>
          <div className="flex items-center gap-1.5 mt-2 text-xs font-semibold text-emerald-600">
            <ArrowUpRight className="w-3.5 h-3.5" />
            <span>+{analytics.overview.sharesGrowth}% share velocity</span>
          </div>
        </div>

        {/* Creator Earnings */}
        <div 
          onClick={() => setActiveMetricTab('earnings')}
          className={`p-5 rounded-2xl border transition-all cursor-pointer ${
            activeMetricTab === 'earnings' 
              ? 'bg-indigo-50/50 border-indigo-300 shadow-sm ring-1 ring-indigo-500/20' 
              : 'bg-white border-neutral-200/80 hover:border-neutral-300'
          }`}
        >
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-600">Gross Earnings</span>
            <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-neutral-900 tracking-tight">
            ${analytics.overview.totalRevenue.toFixed(2)}
          </div>
          <div className="flex items-center gap-1.5 mt-2 text-xs font-semibold text-emerald-600">
            <ArrowUpRight className="w-3.5 h-3.5" />
            <span>+{analytics.overview.revenueGrowth}% paid revenue</span>
          </div>
        </div>

        {/* Avg Read Duration */}
        <div className="p-5 rounded-2xl border bg-white border-neutral-200/80">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-600">Avg Read Time</span>
            <div className="p-1.5 rounded-lg bg-amber-50 text-amber-600">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-neutral-900 tracking-tight">
            {analytics.overview.avgReadTimeMinutes} <span className="text-sm font-normal text-neutral-500">min</span>
          </div>
          <div className="flex items-center gap-1.5 mt-2 text-xs text-neutral-600">
            <span className="font-bold text-neutral-900">+{analytics.overview.subscriberGains}</span>
            <span>new subscribers</span>
          </div>
        </div>

      </div>

      {/* Main Interactive Chart Section */}
      <div className="p-6 rounded-2xl bg-white border border-neutral-200/80 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-neutral-900">
              Audience Engagement Over Time
            </h2>
            <p className="text-xs text-neutral-500">
              Correlating story traffic, complete read rates, and organic shares.
            </p>
          </div>
          <div className="flex items-center gap-4 text-xs font-medium text-neutral-600">
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-full bg-indigo-600" />
              <span>Views</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-full bg-emerald-500" />
              <span>Reads</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-full bg-amber-500" />
              <span>Shares</span>
            </div>
          </div>
        </div>

        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={displayTimeline} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="colorViews" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.25}/>
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorReads" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.25}/>
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorShares" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.25}/>
                  <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="date" tickLine={false} axisLine={false} tick={{ fill: '#64748b', fontSize: 11 }} />
              <YAxis tickLine={false} axisLine={false} tick={{ fill: '#64748b', fontSize: 11 }} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1e293b', 
                  borderRadius: '12px', 
                  border: 'none', 
                  color: '#fff', 
                  fontSize: '12px',
                  boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.2)' 
                }}
              />
              <Area type="monotone" dataKey="views" name="Views" stroke="#6366f1" strokeWidth={2.5} fillOpacity={1} fill="url(#colorViews)" />
              <Area type="monotone" dataKey="reads" name="Reads" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorReads)" />
              <Area type="monotone" dataKey="shares" name="Shares" stroke="#f59e0b" strokeWidth={2} fillOpacity={1} fill="url(#colorShares)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Traffic Sources & Reader Devices Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Traffic Sources */}
        <div className="p-6 rounded-2xl bg-white border border-neutral-200/80 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-base text-neutral-900 flex items-center gap-2">
                <Globe className="w-4 h-4 text-indigo-600" />
                Traffic & Referral Sources
              </h3>
              <span className="text-xs text-neutral-500">Share Attribution</span>
            </div>
            
            <div className="h-44 w-full flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={analytics.trafficSources}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={75}
                    paddingAngle={4}
                    dataKey="percentage"
                  >
                    {analytics.trafficSources.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value: any) => [`${value}%`, 'Share']}
                    contentStyle={{ borderRadius: '8px', fontSize: '11px' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="space-y-2 mt-4 pt-3 border-t border-neutral-100">
            {analytics.trafficSources.map((item) => (
              <div key={item.source} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-neutral-700 truncate max-w-[170px]">{item.source}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-neutral-900">{item.percentage}%</span>
                  <span className="text-neutral-400 text-[11px]">({item.visitors.toLocaleString()})</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Devices & Reading Mediums */}
        <div className="p-6 rounded-2xl bg-white border border-neutral-200/80 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-base text-neutral-900 flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-indigo-600" />
                Devices & Platforms
              </h3>
              <span className="text-xs text-neutral-500">Client Viewports</span>
            </div>

            <div className="space-y-4 my-6">
              {analytics.devices.map((device) => (
                <div key={device.device} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-neutral-700">{device.device}</span>
                    <span className="font-bold text-neutral-900">{device.percentage}%</span>
                  </div>
                  <div className="w-full h-2 bg-neutral-100 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-indigo-500 to-violet-500 rounded-full transition-all duration-500" 
                      style={{ width: `${device.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="p-3 rounded-xl bg-neutral-50 border border-neutral-200/60 text-xs text-neutral-600">
            <span className="font-bold text-neutral-800">Reading Comfort Tip:</span> 56% of your audience reads on desktop screens with serif typography enabled.
          </div>
        </div>

        {/* Global Readership Geo */}
        <div className="p-6 rounded-2xl bg-white border border-neutral-200/80 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-base text-neutral-900 flex items-center gap-2">
                <Globe className="w-4 h-4 text-emerald-600" />
                Top Geographies
              </h3>
              <span className="text-xs text-neutral-500">Global Reach</span>
            </div>

            <div className="space-y-3">
              {analytics.geo.map((geo) => (
                <div key={geo.country} className="flex items-center justify-between text-xs py-1 border-b border-neutral-100 last:border-none">
                  <div className="flex items-center gap-2.5">
                    <span className="text-base">{geo.flag}</span>
                    <span className="font-medium text-neutral-800">{geo.country}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-neutral-500 text-[11px]">{geo.visitors.toLocaleString()} readers</span>
                    <span className="font-bold text-neutral-900 w-8 text-right">{geo.percentage}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={onOpenPremiumModal}
            className="w-full mt-4 py-2 px-3 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Syndicate in 14+ Languages (Pro)</span>
          </button>
        </div>

      </div>

      {/* Top Performing Stories Breakdown Table */}
      <div className="p-6 rounded-2xl bg-white border border-neutral-200/80 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2">
          <div>
            <h3 className="font-bold text-lg text-neutral-900">
              Story Performance Breakdown
            </h3>
            <p className="text-xs text-neutral-500">
              Detailed breakdown of individual article reach, completion ratios, and monetization.
            </p>
          </div>
          <span className="text-xs text-neutral-500 font-medium">
            Showing {posts.length} published stories
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-neutral-200 text-neutral-500 font-bold uppercase tracking-wider">
                <th className="py-3 px-3">Story Title</th>
                <th className="py-3 px-3">Views</th>
                <th className="py-3 px-3">Reads</th>
                <th className="py-3 px-3">Read Ratio</th>
                <th className="py-3 px-3">Claps</th>
                <th className="py-3 px-3">Shares</th>
                <th className="py-3 px-3">Monetization</th>
                <th className="py-3 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100">
              {posts.map((post) => {
                const ratio = post.viewsCount > 0 ? Math.round((post.readsCount / post.viewsCount) * 100) : 0;
                return (
                  <tr key={post.id} className="hover:bg-neutral-50/80 transition-colors">
                    <td className="py-3.5 px-3 max-w-[280px]">
                      <div className="flex items-center gap-2.5">
                        <img 
                          src={post.coverImage} 
                          alt="" 
                          className="w-10 h-10 rounded-lg object-cover shrink-0 border border-neutral-200" 
                        />
                        <div className="truncate">
                          <p 
                            onClick={() => onSelectPost(post)}
                            className="font-bold text-neutral-900 truncate hover:text-indigo-600 cursor-pointer"
                          >
                            {post.title}
                          </p>
                          <span className="text-[11px] text-neutral-500">
                            {post.category} • {post.readTime} min read
                          </span>
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-3 font-semibold text-neutral-800">
                      {post.viewsCount.toLocaleString()}
                    </td>

                    <td className="py-3.5 px-3 font-semibold text-neutral-800">
                      {post.readsCount.toLocaleString()}
                    </td>

                    <td className="py-3.5 px-3">
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-2 bg-neutral-100 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-emerald-500 rounded-full" 
                            style={{ width: `${ratio}%` }}
                          />
                        </div>
                        <span className="font-semibold text-neutral-700">{ratio}%</span>
                      </div>
                    </td>

                    <td className="py-3.5 px-3 font-medium text-neutral-700">
                      👏 {post.claps}
                    </td>

                    <td className="py-3.5 px-3 font-medium text-neutral-700">
                      🔗 {post.sharesCount}
                    </td>

                    <td className="py-3.5 px-3">
                      {post.isPremium ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200 font-bold text-[11px]">
                          <Crown className="w-3 h-3 text-amber-600" />
                          ${post.premiumPrice?.toFixed(2)}
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-neutral-100 text-neutral-600 text-[11px] font-medium">
                          Free
                        </span>
                      )}
                    </td>

                    <td className="py-3.5 px-3 text-right">
                      <button
                        onClick={() => onSelectPost(post)}
                        className="p-1.5 hover:bg-neutral-200 text-neutral-600 hover:text-neutral-900 rounded-lg transition-colors inline-flex items-center gap-1"
                        title="View Full Story"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
