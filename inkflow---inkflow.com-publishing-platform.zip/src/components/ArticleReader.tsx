import React, { useState, useEffect, useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { 
  ArrowLeft, 
  Heart, 
  Share2, 
  Bookmark, 
  MessageSquare, 
  Crown, 
  Lock, 
  Sparkles, 
  Check, 
  Clock, 
  Eye, 
  Type, 
  Sun, 
  Moon, 
  BookOpen, 
  Send,
  UserCheck,
  UserPlus
} from 'lucide-react';
import { Post, StoryComment, UserProfile, ReaderFont } from '../types';
import { INITIAL_COMMENTS } from '../data/mockData';

interface ArticleReaderProps {
  post: Post;
  currentUser: UserProfile;
  onBack: () => void;
  onOpenShareModal: (post: Post) => void;
  onOpenPremiumModal: () => void;
  onUpdatePostClaps: (postId: string, newClaps: number) => void;
}

export const ArticleReader: React.FC<ArticleReaderProps> = ({
  post,
  currentUser,
  onBack,
  onOpenShareModal,
  onOpenPremiumModal,
  onUpdatePostClaps,
}) => {
  const [claps, setClaps] = useState(post.claps);
  const [userClappedSession, setUserClappedSession] = useState(0);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [isFollowingAuthor, setIsFollowingAuthor] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  
  // Reading mode customization
  const [readerFont, setReaderFont] = useState<ReaderFont>('serif');
  const [fontSize, setFontSize] = useState<'normal' | 'large' | 'xl'>('normal');
  const [themeMode, setThemeMode] = useState<'light' | 'sepia' | 'dark'>('light');

  // Comments state
  const [comments, setComments] = useState<StoryComment[]>(
    INITIAL_COMMENTS.filter((c) => c.postId === post.id)
  );
  const [newCommentText, setNewCommentText] = useState('');
  const [isUnlockedForReader, setIsUnlockedForReader] = useState(!post.isPremium || currentUser.subscriptionActive);

  // Floating clap animation state
  const [clapBubble, setClapBubble] = useState<{ id: number; value: number }[]>([]);

  // Track scroll progress
  useEffect(() => {
    const handleScroll = () => {
      const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
      if (totalHeight > 0) {
        const progress = Math.min(100, Math.max(0, (window.scrollY / totalHeight) * 100));
        setScrollProgress(progress);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleClap = () => {
    const nextClaps = claps + 1;
    const nextSession = userClappedSession + 1;
    setClaps(nextClaps);
    setUserClappedSession(nextSession);
    onUpdatePostClaps(post.id, nextClaps);

    const bubbleId = Date.now();
    setClapBubble((prev) => [...prev, { id: bubbleId, value: nextSession }]);
    setTimeout(() => {
      setClapBubble((prev) => prev.filter((b) => b.id !== bubbleId));
    }, 1000);
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentText.trim()) return;

    const newComment: StoryComment = {
      id: `c_${Date.now()}`,
      postId: post.id,
      authorName: currentUser.name,
      authorAvatar: currentUser.avatar,
      content: newCommentText.trim(),
      createdAt: 'Just now',
      likes: 0,
    };

    setComments([newComment, ...comments]);
    setNewCommentText('');
  };

  // Determine split content if paywalled
  const paragraphs = post.content.split('\n\n');
  const isPaywalled = post.isPremium && !isUnlockedForReader;
  const renderedContent = isPaywalled ? paragraphs.slice(0, 3).join('\n\n') : post.content;

  // Theme styling helpers
  const getThemeClasses = () => {
    if (themeMode === 'sepia') return 'bg-[#fbf7ee] text-[#332b25]';
    if (themeMode === 'dark') return 'bg-[#18181b] text-[#f4f4f5]';
    return 'bg-white text-neutral-900';
  };

  const getFontClasses = () => {
    if (readerFont === 'sans') return 'font-sans-custom';
    if (readerFont === 'mono') return 'font-mono-custom';
    return 'font-serif-custom';
  };

  const getFontSizeClasses = () => {
    if (fontSize === 'large') return 'text-xl leading-relaxed';
    if (fontSize === 'xl') return 'text-2xl leading-loose';
    return 'text-lg leading-relaxed';
  };

  return (
    <div id="article-reader-container" className={`min-h-screen transition-colors duration-200 ${getThemeClasses()}`}>
      
      {/* Top Reading Progress Bar */}
      <div className="fixed top-0 left-0 right-0 h-1 bg-neutral-200/50 z-50">
        <div 
          className="h-full bg-gradient-to-r from-indigo-600 to-violet-600 transition-all duration-150"
          style={{ width: `${scrollProgress}%` }}
        />
      </div>

      {/* Reader Control Header */}
      <div className={`sticky top-16 z-30 border-b transition-colors backdrop-blur-md ${
        themeMode === 'dark' 
          ? 'bg-neutral-900/90 border-neutral-800 text-neutral-300' 
          : themeMode === 'sepia' 
          ? 'bg-[#f5efe3]/90 border-[#e8ded0] text-amber-950' 
          : 'bg-white/90 border-neutral-200 text-neutral-700'
      }`}>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-4">
          
          <button
            id="reader-back-to-feed-btn"
            onClick={onBack}
            className="flex items-center gap-1.5 text-xs font-semibold hover:opacity-75 transition-opacity"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Feed</span>
          </button>

          {/* Reading Display Settings */}
          <div className="flex items-center gap-2 sm:gap-4">
            
            {/* Font selector */}
            <div className="flex items-center gap-1 bg-black/5 dark:bg-white/10 p-0.5 rounded-lg text-xs font-medium">
              <button
                onClick={() => setReaderFont('serif')}
                className={`px-2 py-0.5 rounded font-serif ${readerFont === 'serif' ? 'bg-white text-neutral-900 shadow-xs' : ''}`}
                title="Serif font"
              >
                Serif
              </button>
              <button
                onClick={() => setReaderFont('sans')}
                className={`px-2 py-0.5 rounded font-sans ${readerFont === 'sans' ? 'bg-white text-neutral-900 shadow-xs' : ''}`}
                title="Sans font"
              >
                Sans
              </button>
              <button
                onClick={() => setReaderFont('mono')}
                className={`px-2 py-0.5 rounded font-mono ${readerFont === 'mono' ? 'bg-white text-neutral-900 shadow-xs' : ''}`}
                title="Monospace font"
              >
                Mono
              </button>
            </div>

            {/* Font Size */}
            <div className="flex items-center gap-1 bg-black/5 dark:bg-white/10 p-0.5 rounded-lg text-xs font-bold">
              <button
                onClick={() => setFontSize('normal')}
                className={`px-1.5 py-0.5 rounded ${fontSize === 'normal' ? 'bg-white text-neutral-900 shadow-xs' : ''}`}
              >
                A
              </button>
              <button
                onClick={() => setFontSize('large')}
                className={`px-1.5 py-0.5 rounded text-sm ${fontSize === 'large' ? 'bg-white text-neutral-900 shadow-xs' : ''}`}
              >
                A+
              </button>
            </div>

            {/* Theme selector */}
            <div className="flex items-center gap-1 bg-black/5 dark:bg-white/10 p-0.5 rounded-lg">
              <button
                onClick={() => setThemeMode('light')}
                className={`p-1 rounded ${themeMode === 'light' ? 'bg-white text-neutral-900 shadow-xs' : 'text-neutral-500'}`}
                title="Light mode"
              >
                <Sun className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setThemeMode('sepia')}
                className={`px-2 py-0.5 text-xs font-semibold rounded ${themeMode === 'sepia' ? 'bg-[#e2d5c2] text-amber-950 shadow-xs' : 'text-neutral-500'}`}
                title="Sepia vintage"
              >
                Sepia
              </button>
              <button
                onClick={() => setThemeMode('dark')}
                className={`p-1 rounded ${themeMode === 'dark' ? 'bg-neutral-800 text-white shadow-xs' : 'text-neutral-500'}`}
                title="Dark night mode"
              >
                <Moon className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Share Trigger */}
            <button
              onClick={() => onOpenShareModal(post)}
              className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs transition-colors"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Share</span>
            </button>

          </div>

        </div>
      </div>

      {/* Article Content Container */}
      <article className="max-w-3xl mx-auto px-4 sm:px-6 py-10 sm:py-16 space-y-8">
        
        {/* Category & Premium Tag */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
            {post.category}
          </span>
          {post.isPremium && (
            <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-amber-500/10 text-amber-800 dark:text-amber-300 border border-amber-300/80">
              <Crown className="w-3 h-3 text-amber-600 dark:text-amber-400" />
              Premium Story
            </span>
          )}
        </div>

        {/* Title & Subtitle */}
        <div className="space-y-4">
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight font-serif-custom leading-tight">
            {post.title}
          </h1>
          {post.subtitle && (
            <p className="text-lg sm:text-xl text-neutral-600 dark:text-neutral-400 font-sans-custom leading-relaxed">
              {post.subtitle}
            </p>
          )}
        </div>

        {/* Author Info & Story Meta Bar */}
        <div className="flex items-center justify-between py-6 border-y border-neutral-200/80 dark:border-neutral-800 gap-4 flex-wrap">
          <div className="flex items-center gap-3.5">
            <img
              src={post.author.avatar}
              alt={post.author.name}
              className="w-12 h-12 rounded-full object-cover ring-2 ring-indigo-500/30"
            />
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm sm:text-base font-sans-custom">
                  {post.author.name}
                </span>
                {post.author.isVerified && (
                  <span className="w-4 h-4 rounded-full bg-indigo-600 text-white flex items-center justify-center text-[10px]">
                    ✓
                  </span>
                )}
                <button
                  onClick={() => setIsFollowingAuthor(!isFollowingAuthor)}
                  className={`ml-1 text-xs font-bold px-2.5 py-0.5 rounded-full border transition-all ${
                    isFollowingAuthor
                      ? 'bg-neutral-100 dark:bg-neutral-800 border-neutral-300 text-neutral-700 dark:text-neutral-300'
                      : 'bg-indigo-50 dark:bg-indigo-950 border-indigo-200 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100'
                  }`}
                >
                  {isFollowingAuthor ? 'Following' : '+ Follow'}
                </button>
              </div>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                {new Date(post.publishedAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })} • {post.readTime} min read • {post.wordCount} words
              </p>
            </div>
          </div>

          {/* Social Interactions Pill */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleClap}
              className="relative flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 text-xs font-bold transition-all active:scale-95"
            >
              <span>👏</span>
              <span>{claps}</span>

              {/* Animated Floating Bubbles */}
              {clapBubble.map((b) => (
                <span
                  key={b.id}
                  className="absolute -top-7 left-1/2 -translate-x-1/2 text-xs font-extrabold text-indigo-600 animate-bounce pointer-events-none"
                >
                  +{b.value}
                </span>
              ))}
            </button>

            <button
              onClick={() => setIsBookmarked(!isBookmarked)}
              className={`p-2 rounded-full border transition-colors ${
                isBookmarked
                  ? 'bg-indigo-50 border-indigo-300 text-indigo-600'
                  : 'bg-neutral-100 dark:bg-neutral-800 border-neutral-200 dark:border-neutral-700 text-neutral-500'
              }`}
              title="Bookmark story"
            >
              <Bookmark className="w-4 h-4" />
            </button>

            <button
              onClick={() => onOpenShareModal(post)}
              className="p-2 rounded-full bg-neutral-100 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-neutral-500 hover:text-neutral-900 transition-colors"
              title="Share story"
            >
              <Share2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Cover Image */}
        {post.coverImage && (
          <div className="rounded-2xl overflow-hidden shadow-sm border border-neutral-200 dark:border-neutral-800">
            <img
              src={post.coverImage}
              alt={post.title}
              className="w-full max-h-[440px] object-cover"
            />
          </div>
        )}

        {/* Markdown Rendered Story Body */}
        <div className={`markdown-body ${getFontClasses()} ${getFontSizeClasses()}`}>
          <ReactMarkdown remarkPlugins={[remarkGfm]}>
            {renderedContent}
          </ReactMarkdown>
        </div>

        {/* Paywall Gate Container (if reader is locked) */}
        {isPaywalled && (
          <div className="relative mt-8 pt-12 pb-10 text-center rounded-3xl bg-gradient-to-b from-transparent via-neutral-100/90 to-neutral-200/90 dark:via-neutral-900/90 dark:to-neutral-950 border border-neutral-300 dark:border-neutral-800 shadow-xl overflow-hidden p-6 sm:p-10 space-y-6">
            
            <div className="w-14 h-14 bg-gradient-to-tr from-amber-500 to-orange-500 rounded-2xl flex items-center justify-center text-white mx-auto shadow-md shadow-amber-500/30">
              <Lock className="w-7 h-7" />
            </div>

            <div className="space-y-2 max-w-lg mx-auto">
              <h3 className="text-2xl font-extrabold tracking-tight font-sans-custom">
                Read the Full Story with Writer Pro
              </h3>
              <p className="text-sm text-neutral-600 dark:text-neutral-400 leading-relaxed">
                This story is exclusively available to Inkflow Pro subscribers. Join today to read unlimited premium essays, unlock audience analytics, and share your own written content.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 max-w-md mx-auto">
              <button
                onClick={() => {
                  setIsUnlockedForReader(true);
                }}
                className="w-full sm:w-auto px-6 py-3 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-xs font-bold hover:bg-neutral-50 dark:hover:bg-neutral-700 transition-all shadow-xs"
              >
                Unlock Story (${post.premiumPrice?.toFixed(2) || '4.99'})
              </button>

              <button
                onClick={onOpenPremiumModal}
                className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white text-xs font-bold shadow-md shadow-amber-500/25 transition-all hover:scale-105 flex items-center justify-center gap-1.5"
              >
                <Sparkles className="w-4 h-4" />
                <span>Join Writer Pro ($12/mo)</span>
              </button>
            </div>

          </div>
        )}

        {/* Tags footer */}
        {post.tags && post.tags.length > 0 && (
          <div className="pt-8 border-t border-neutral-200 dark:border-neutral-800 flex flex-wrap gap-2">
            {post.tags.map((tag) => (
              <span
                key={tag}
                className="px-3 py-1 rounded-full text-xs font-medium bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300"
              >
                #{tag}
              </span>
            ))}
          </div>
        )}

        {/* Author Bio Footer Box */}
        <div className="p-6 rounded-2xl bg-neutral-100/70 dark:bg-neutral-800/50 border border-neutral-200 dark:border-neutral-700 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-start gap-4">
            <img
              src={post.author.avatar}
              alt={post.author.name}
              className="w-14 h-14 rounded-full object-cover ring-2 ring-indigo-500/30"
            />
            <div>
              <h4 className="font-bold text-base">{post.author.name}</h4>
              <p className="text-xs text-neutral-600 dark:text-neutral-400 mt-1 max-w-md">
                {post.author.bio}
              </p>
              <span className="text-[11px] text-neutral-500 mt-1 block">
                {post.author.followersCount.toLocaleString()} followers
              </span>
            </div>
          </div>
          <button
            onClick={() => onOpenShareModal(post)}
            className="px-4 py-2 rounded-xl bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 text-xs font-bold hover:opacity-90 transition-opacity flex items-center gap-1.5 shrink-0"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>Share Story</span>
          </button>
        </div>

        {/* Comments Section */}
        <div className="pt-10 border-t border-neutral-200 dark:border-neutral-800 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-lg flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-indigo-600" />
              <span>Responses ({comments.length})</span>
            </h3>
          </div>

          {/* Add Comment Box */}
          <form onSubmit={handleAddComment} className="space-y-3">
            <div className="flex gap-3">
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-8 h-8 rounded-full object-cover shrink-0"
              />
              <textarea
                value={newCommentText}
                onChange={(e) => setNewCommentText(e.target.value)}
                placeholder="What are your thoughts on this essay?"
                rows={2}
                className="flex-1 text-xs sm:text-sm bg-neutral-50 dark:bg-neutral-800/80 border border-neutral-200 dark:border-neutral-700 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none resize-none"
              />
            </div>
            <div className="flex justify-end">
              <button
                type="submit"
                disabled={!newCommentText.trim()}
                className="px-4 py-1.5 rounded-lg bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 text-xs font-bold disabled:opacity-40 transition-opacity flex items-center gap-1.5"
              >
                <Send className="w-3 h-3" />
                <span>Publish Response</span>
              </button>
            </div>
          </form>

          {/* Comments List */}
          <div className="space-y-4 pt-2">
            {comments.map((comment) => (
              <div key={comment.id} className="p-4 rounded-xl bg-neutral-50/70 dark:bg-neutral-800/40 border border-neutral-200/80 dark:border-neutral-700/80 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <img
                      src={comment.authorAvatar}
                      alt={comment.authorName}
                      className="w-6 h-6 rounded-full object-cover"
                    />
                    <span className="font-bold">{comment.authorName}</span>
                    <span className="text-neutral-400">•</span>
                    <span className="text-neutral-500">{comment.createdAt}</span>
                  </div>
                  <button className="text-xs text-neutral-500 hover:text-indigo-600 flex items-center gap-1 font-medium">
                    👏 {comment.likes > 0 && comment.likes}
                  </button>
                </div>
                <p className="text-xs sm:text-sm text-neutral-700 dark:text-neutral-300 leading-relaxed font-sans-custom">
                  {comment.content}
                </p>
              </div>
            ))}
          </div>

        </div>

      </article>

    </div>
  );
};
