import { useState } from 'react';
import { 
  PenTool, 
  Share2, 
  Trash2, 
  ExternalLink, 
  Crown, 
  Lock, 
  Plus, 
  Sparkles, 
  BookOpen, 
  Eye, 
  Clock, 
  BarChart3,
  MoreVertical,
  CheckCircle2,
  Copy
} from 'lucide-react';
import { Post, UserProfile } from '../types';

interface MyStoriesProps {
  posts: Post[];
  currentUser: UserProfile;
  onEditPost: (post: Post) => void;
  onSelectPost: (post: Post) => void;
  onOpenShareModal: (post: Post) => void;
  onOpenPremiumModal: () => void;
  onNewStory: () => void;
  onDeletePost: (postId: string) => void;
}

export const MyStories: React.FC<MyStoriesProps> = ({
  posts,
  currentUser,
  onEditPost,
  onSelectPost,
  onOpenShareModal,
  onOpenPremiumModal,
  onNewStory,
  onDeletePost,
}) => {
  const [filterTab, setFilterTab] = useState<'all' | 'published' | 'drafts' | 'monetized'>('all');

  // Filter only user authored posts (or posts with author id = usr_me)
  const myPosts = posts.filter((p) => p.author.id === currentUser.id);

  const filteredPosts = myPosts.filter((p) => {
    if (filterTab === 'published') return p.status === 'published';
    if (filterTab === 'drafts') return p.status === 'draft';
    if (filterTab === 'monetized') return p.isPremium;
    return true;
  });

  const totalMyViews = myPosts.reduce((acc, curr) => acc + curr.viewsCount, 0);
  const totalMyReads = myPosts.reduce((acc, curr) => acc + curr.readsCount, 0);
  const totalMyShares = myPosts.reduce((acc, curr) => acc + curr.sharesCount, 0);

  return (
    <div id="my-stories-dashboard" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-neutral-200">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 tracking-tight font-sans-custom">
            Writer Management Studio
          </h1>
          <p className="text-sm text-neutral-600 mt-1">
            Manage your drafts, publish new stories, and monitor active share links.
          </p>
        </div>

        <button
          onClick={onNewStory}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs sm:text-sm font-bold shadow-sm transition-all hover:scale-105"
        >
          <Plus className="w-4 h-4" />
          <span>New Story</span>
        </button>
      </div>

      {/* Writer Stats Summary Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="p-5 rounded-2xl bg-white border border-neutral-200/80 shadow-xs">
          <span className="text-xs font-bold uppercase tracking-wider text-neutral-500">My Stories</span>
          <div className="text-2xl font-extrabold text-neutral-900 mt-1">
            {myPosts.length} <span className="text-xs font-normal text-neutral-500">authored</span>
          </div>
          <p className="text-xs text-neutral-500 mt-1">
            {myPosts.filter(p => p.status === 'published').length} live published
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-neutral-200/80 shadow-xs">
          <span className="text-xs font-bold uppercase tracking-wider text-neutral-500">Total Readership</span>
          <div className="text-2xl font-extrabold text-neutral-900 mt-1">
            {totalMyViews.toLocaleString()} <span className="text-xs font-normal text-neutral-500">views</span>
          </div>
          <p className="text-xs text-emerald-600 font-semibold mt-1">
            {totalMyReads.toLocaleString()} complete reads
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-neutral-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-500">Share Pass Status</span>
            {currentUser.subscriptionActive ? (
              <Crown className="w-3.5 h-3.5 text-amber-500" />
            ) : (
              <Lock className="w-3.5 h-3.5 text-neutral-400" />
            )}
          </div>
          <div className="text-lg font-bold text-neutral-900 mt-1 flex items-center gap-1.5">
            {currentUser.subscriptionActive ? (
              <span className="text-emerald-700 font-extrabold text-sm flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                Writer Pro Active
              </span>
            ) : (
              <span className="text-neutral-700 text-sm font-semibold">
                Free (Sharing Locked)
              </span>
            )}
          </div>
          <p className="text-xs text-neutral-500 mt-1">
            {currentUser.subscriptionActive 
              ? `${totalMyShares} active syndicated shares` 
              : 'Upgrade to distribute stories'}
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-neutral-200/80 shadow-xs flex flex-col justify-between">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-500">Gross Earnings</span>
            <div className="text-2xl font-extrabold text-neutral-900 mt-1">
              ${currentUser.totalEarnings.toFixed(2)}
            </div>
          </div>
          <div className="flex items-center justify-between text-xs text-neutral-500 mt-1">
            <span>Pending balance:</span>
            <span className="font-bold text-emerald-600">${currentUser.unpaidBalance.toFixed(2)}</span>
          </div>
        </div>

      </div>

      {/* Filter Tabs */}
      <div className="flex items-center justify-between gap-4 border-b border-neutral-200">
        <div className="flex items-center gap-1">
          <button
            onClick={() => setFilterTab('all')}
            className={`pb-3 px-3 text-xs sm:text-sm font-bold border-b-2 transition-all ${
              filterTab === 'all'
                ? 'border-neutral-900 text-neutral-900'
                : 'border-transparent text-neutral-500 hover:text-neutral-900'
            }`}
          >
            All Stories ({myPosts.length})
          </button>
          <button
            onClick={() => setFilterTab('published')}
            className={`pb-3 px-3 text-xs sm:text-sm font-bold border-b-2 transition-all ${
              filterTab === 'published'
                ? 'border-neutral-900 text-neutral-900'
                : 'border-transparent text-neutral-500 hover:text-neutral-900'
            }`}
          >
            Published ({myPosts.filter(p => p.status === 'published').length})
          </button>
          <button
            onClick={() => setFilterTab('monetized')}
            className={`pb-3 px-3 text-xs sm:text-sm font-bold border-b-2 transition-all ${
              filterTab === 'monetized'
                ? 'border-neutral-900 text-neutral-900'
                : 'border-transparent text-neutral-500 hover:text-neutral-900'
            }`}
          >
            Monetized Stories ({myPosts.filter(p => p.isPremium).length})
          </button>
        </div>
      </div>

      {/* Stories List */}
      <div className="space-y-4">
        {filteredPosts.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-2xl border border-neutral-200 space-y-3">
            <BookOpen className="w-12 h-12 text-neutral-300 mx-auto" />
            <h3 className="font-bold text-base text-neutral-800">No stories in this view</h3>
            <p className="text-xs text-neutral-500 max-w-sm mx-auto">
              Draft your next essay, technical tutorial, or philosophical reflection.
            </p>
            <button
              onClick={onNewStory}
              className="mt-2 px-4 py-2 rounded-xl bg-neutral-900 text-white text-xs font-bold"
            >
              Write First Story
            </button>
          </div>
        ) : (
          filteredPosts.map((post) => (
            <div
              key={post.id}
              className="p-5 rounded-2xl bg-white border border-neutral-200/80 hover:border-neutral-300 shadow-xs transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
            >
              <div className="flex items-start gap-4 max-w-2xl">
                <img
                  src={post.coverImage}
                  alt=""
                  className="w-16 h-16 rounded-xl object-cover shrink-0 border border-neutral-200 hidden sm:block"
                />
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-neutral-100 text-neutral-700">
                      {post.category}
                    </span>
                    {post.isPremium ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200">
                        <Crown className="w-3 h-3 text-amber-600" />
                        Monetized (${post.premiumPrice?.toFixed(2)})
                      </span>
                    ) : (
                      <span className="text-[11px] px-2 py-0.5 rounded bg-neutral-100 text-neutral-500">
                        Free Story
                      </span>
                    )}
                    <span className="text-xs text-neutral-400">
                      Updated {new Date(post.updatedAt).toLocaleDateString()}
                    </span>
                  </div>

                  <h3 
                    onClick={() => onSelectPost(post)}
                    className="font-bold text-base text-neutral-900 hover:text-indigo-600 cursor-pointer font-serif-custom"
                  >
                    {post.title}
                  </h3>

                  <p className="text-xs text-neutral-500 line-clamp-1">
                    {post.subtitle || post.content.substring(0, 100)}
                  </p>

                  <div className="flex items-center gap-3 text-xs text-neutral-500 pt-1">
                    <span className="flex items-center gap-1"><Eye className="w-3.5 h-3.5" /> {post.viewsCount.toLocaleString()} views</span>
                    <span>•</span>
                    <span>👏 {post.claps} claps</span>
                    <span>•</span>
                    <span>🔗 {post.sharesCount} shares</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 w-full sm:w-auto justify-end pt-2 sm:pt-0 border-t sm:border-t-0 border-neutral-100">
                {/* Share Button (Checks Premium status!) */}
                <button
                  onClick={() => onOpenShareModal(post)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    currentUser.subscriptionActive
                      ? 'bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200'
                      : 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white shadow-xs'
                  }`}
                  title="Share and distribute content"
                >
                  {currentUser.subscriptionActive ? (
                    <>
                      <Share2 className="w-3.5 h-3.5" />
                      <span>Share</span>
                    </>
                  ) : (
                    <>
                      <Crown className="w-3.5 h-3.5" />
                      <span>Share (Pro)</span>
                    </>
                  )}
                </button>

                {/* Edit in Studio */}
                <button
                  onClick={() => onEditPost(post)}
                  className="p-2 rounded-xl border border-neutral-200 text-neutral-700 hover:bg-neutral-100 transition-colors"
                  title="Edit story in Markdown Studio"
                >
                  <PenTool className="w-3.5 h-3.5" />
                </button>

                {/* View Story */}
                <button
                  onClick={() => onSelectPost(post)}
                  className="p-2 rounded-xl border border-neutral-200 text-neutral-700 hover:bg-neutral-100 transition-colors"
                  title="Read full story"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>

                {/* Delete story */}
                <button
                  onClick={() => onDeletePost(post.id)}
                  className="p-2 rounded-xl border border-neutral-200 text-neutral-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                  title="Delete story"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

            </div>
          ))
        )}
      </div>

    </div>
  );
};
