import { Post, UserProfile, AudienceAnalyticsData, StoryComment } from '../types';

export const CURRENT_USER: UserProfile = {
  id: 'usr_me',
  name: 'Elena Rostova',
  handle: '@elenarostova',
  email: 'elena.rostova@inkflow.com',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  bio: 'Staff Writer & Systems Designer exploring the intersection of creative tooling, distributed systems, and cognitive craft.',
  tier: 'free', // initially free to showcase the Premium sharing requirement!
  subscriptionActive: false,
  totalEarnings: 1420.50,
  unpaidBalance: 285.00,
  followersCount: 1840,
  followingCount: 312,
  sharesRemainingForFree: 0, // Requires premium to share
};

export const INITIAL_POSTS: Post[] = [
  {
    id: 'post-1',
    title: 'The Architecture of Deep Focus: Designing Quiet Digital Spaces',
    subtitle: 'Why the next decade of software craftsmanship belongs to calm interfaces and intentional friction.',
    slug: 'architecture-of-deep-focus',
    content: `# The Architecture of Deep Focus: Designing Quiet Digital Spaces

In an era of relentless algorithmic urgency, our tools have subtly shifted from extensions of the human mind into slot machines for attention. When we write, design, or synthesize complex systems, we do not merely require utility—we require **quietude**.

> "A tool should invite mastery rather than demand vigilance." — *Christopher Alexander, Notes on the Synthesis of Form*

## The Problem with Modern Information Density

Most contemporary productivity tools optimize for engagement loops rather than completion rates. Consider the standard modern workspace:

- **Ephemeral Notifications:** Micro-pings that destroy flow states within 90 seconds.
- **Visual Cacophony:** Over 15 disparate accent colors competing for visual weight.
- **Premature Automation:** AI suggestions that disrupt the delicate germination of a nascent thought.

\`\`\`typescript
// The cognitive load equation
interface CognitiveState {
  workingMemoryTokens: number;
  externalInterruptFrequencyHz: number;
  flowStateResilience: number;
}

function calculateThoughtDecay(state: CognitiveState): number {
  return (state.externalInterruptFrequencyHz * 1.618) / Math.max(0.1, state.flowStateResilience);
}
\`\`\`

---

## The Four Principles of Quiet Software

1. **Subtractive by Default:** Every pixel, button, and indicator must justify its cognitive footprint.
2. **Predictable Rhythms:** No sudden shifts in layout or unsolicited popups during active composing.
3. **Typography as Structure:** Let hierarchy, whitespace, and font weight carry the narrative rather than heavy borders.
4. **Data Sovereignty:** The writer owns their canvas without artificial syndication barriers.

| Metric | Loud Architecture | Quiet Architecture |
| :--- | :--- | :--- |
| **Context Switch Cost** | 23 minutes / interruption | < 45 seconds |
| **Active Focus Window** | 12.4 minutes | 54.2 minutes |
| **Writer Satisfaction** | 38% | 94% |

### Building for the Long Horizon

When we construct tools that respect cognitive bandwidth, we elevate both the process of creation and the resulting prose. The goal is not just faster output, but deeper resonance.`,
    coverImage: 'https://images.unsplash.com/photo-1499750310107-5fef28a66643?w=1200&auto=format&fit=crop&q=80',
    tags: ['Design', 'Productivity', 'Philosophy', 'Writing'],
    category: 'Design & Craft',
    author: {
      id: 'usr_me',
      name: 'Elena Rostova',
      handle: '@elenarostova',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      bio: 'Staff Writer & Systems Designer exploring the intersection of creative tooling and cognitive craft.',
      tier: 'free',
      followersCount: 1840,
      isVerified: true,
    },
    status: 'published',
    publishedAt: '2026-08-20T10:30:00Z',
    updatedAt: '2026-08-21T14:15:00Z',
    readTime: 6,
    wordCount: 1140,
    isPremium: true,
    paywallType: 'premium_only',
    premiumPrice: 4.99,
    claps: 342,
    bookmarksCount: 89,
    viewsCount: 4820,
    readsCount: 3120,
    commentsCount: 18,
    sharesCount: 142,
    customShareSlug: 'deep-focus-manifesto',
    allowComments: true,
    featured: true,
  },
  {
    id: 'post-2',
    title: 'Building Modern Markdown Engines: AST Parsing to Instant Render',
    subtitle: 'A deep technical journey into Abstract Syntax Trees, incremental lexing, and sub-millisecond previews.',
    slug: 'modern-markdown-engines-ast-parsing',
    content: `# Building Modern Markdown Engines: AST Parsing to Instant Render

Writing in markdown is beloved because it separates structure from presentation. However, rendering large documents with reactive state without stuttering requires understanding the parser pipeline.

## The AST Pipeline

When markdown text is parsed, it undergoes three distinct phases:

1. **Tokenization (Lexer):** Raw character streams are divided into semantic tokens (headings, lists, code spans).
2. **Tree Construction (Parser):** Tokens are organized into an Abstract Syntax Tree (AST) representing the nested hierarchy.
3. **Compilation/Transformation:** AST nodes are mapped into React Virtual DOM elements or direct HTML nodes.

\`\`\`rust
// Simplified token scanner pattern in Rust / WASM
pub enum Token {
    Heading(u8, String),
    Paragraph(String),
    CodeBlock { lang: Option<String>, code: String },
    Blockquote(Box<Token>),
    ListItem(String),
}
\`\`\`

## Optimizing for 60fps Typing

To prevent UI lag when authors type hundreds of words per minute:
- Use debounced compilation for heavy syntax highlighters.
- Render visible AST nodes using viewport virtualization when documents exceed 10,000 words.
- Maintain an immutable snapshot of previous document blocks.`,
    coverImage: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=1200&auto=format&fit=crop&q=80',
    tags: ['Engineering', 'Markdown', 'Compilers', 'TypeScript'],
    category: 'Engineering',
    author: {
      id: 'usr_2',
      name: 'Julian Vance',
      handle: '@julianvance',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      bio: 'Compiler engineer and open source maintainer.',
      tier: 'pro',
      followersCount: 3200,
      isVerified: true,
    },
    status: 'published',
    publishedAt: '2026-08-18T14:00:00Z',
    updatedAt: '2026-08-19T09:00:00Z',
    readTime: 5,
    wordCount: 890,
    isPremium: false,
    paywallType: 'free',
    claps: 215,
    bookmarksCount: 64,
    viewsCount: 3410,
    readsCount: 2480,
    commentsCount: 12,
    sharesCount: 98,
    allowComments: true,
    featured: false,
  },
  {
    id: 'post-3',
    title: 'The Economics of the Modern Indie Newsletter in 2026',
    subtitle: 'Deconstructing subscriber churn, multi-tier paywalls, and cross-platform content syndication.',
    slug: 'economics-indie-newsletter-2026',
    content: `# The Economics of the Modern Indie Newsletter in 2026

The solo writer business model has undergone a profound transformation. Moving beyond basic subscription paywalls, independent creators now operate specialized media ecosystems.

## Unit Economics of an Independent Publication

Let's examine the baseline financial structure of a 5,000-subscriber publication:

- **Free Tier Readership:** 5,000 subscribers
- **Paid Conversion Rate:** 4.5% (225 paid subscribers)
- **Average Monthly Price:** $8.00 / month
- **Gross Monthly Recurring Revenue (MRR):** $1,800.00
- **Annual Run Rate:** $21,600.00

### Why Premium Distribution Channels Matter

Writers who rely solely on single-platform email delivery suffer from delivery fatigue and mailbox promotions tab segregation. Unlocking **multichannel syndication and branded share passes** boosts conversion by over 60%.

> "Distribution is not something you tack on after writing; distribution is the bridge between your perspective and the world's consciousness."`,
    coverImage: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=1200&auto=format&fit=crop&q=80',
    tags: ['Economics', 'Publishing', 'Monetization', 'Media'],
    category: 'Economics',
    author: {
      id: 'usr_me',
      name: 'Elena Rostova',
      handle: '@elenarostova',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      bio: 'Staff Writer & Systems Designer exploring the intersection of creative tooling and cognitive craft.',
      tier: 'free',
      followersCount: 1840,
      isVerified: true,
    },
    status: 'published',
    publishedAt: '2026-08-14T08:15:00Z',
    updatedAt: '2026-08-15T11:20:00Z',
    readTime: 7,
    wordCount: 1320,
    isPremium: true,
    paywallType: 'metered',
    premiumPrice: 5.00,
    claps: 512,
    bookmarksCount: 140,
    viewsCount: 6890,
    readsCount: 4920,
    commentsCount: 29,
    sharesCount: 310,
    allowComments: true,
    featured: true,
  },
  {
    id: 'post-4',
    title: 'Reflections on Solitude and the Writer’s Craft',
    subtitle: 'Finding sanctuary in unstructured silence to cultivate genuine creative voice.',
    slug: 'reflections-on-solitude-and-craft',
    content: `# Reflections on Solitude and the Writer’s Craft

We are rarely alone in the 21st century. Even when our physical rooms are empty, our mental corridors are crowded with ghosts of conversations past and notifications pending.

## Cultivating the Unbothered Mind

Solitude is not isolation; it is the presence of one's own unobstructed perspective. When we write from a place of perpetual input, our sentences become defensive—anticipating objections before the thesis has even coalesced.

### Daily Rituals for Uncompromised Output

1. **Morning Analog Window:** First 45 minutes of the day spent without backlit displays.
2. **Single-Task Draft Sessions:** A 60-minute markdown sprint with zero browser tabs open.
3. **Read Five Times What You Write:** Sustained ingestion of classic essays and poetry.`,
    coverImage: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=1200&auto=format&fit=crop&q=80',
    tags: ['Literature', 'Mindfulness', 'Essays', 'Craft'],
    category: 'Literature',
    author: {
      id: 'usr_3',
      name: 'Claire Moreau',
      handle: '@clairemoreau',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
      bio: 'Essayist, translator, and fellow in comparative literature.',
      tier: 'pro',
      followersCount: 4120,
      isVerified: true,
    },
    status: 'published',
    publishedAt: '2026-08-10T16:45:00Z',
    updatedAt: '2026-08-10T16:45:00Z',
    readTime: 4,
    wordCount: 750,
    isPremium: false,
    paywallType: 'free',
    claps: 184,
    bookmarksCount: 52,
    viewsCount: 2150,
    readsCount: 1690,
    commentsCount: 9,
    sharesCount: 67,
    allowComments: true,
    featured: false,
  }
];

export const INITIAL_ANALYTICS: AudienceAnalyticsData = {
  overview: {
    totalViews: 17270,
    viewsGrowth: 24.8,
    totalReads: 12210,
    readsGrowth: 18.3,
    avgReadRatio: 70.7,
    avgReadTimeMinutes: 5.6,
    totalShares: 617,
    sharesGrowth: 41.2,
    totalRevenue: 1420.50,
    revenueGrowth: 32.5,
    subscriberGains: 218,
  },
  timeline: [
    { date: 'Aug 1', views: 420, reads: 290, visitors: 380, shares: 14, earnings: 28 },
    { date: 'Aug 4', views: 590, reads: 410, visitors: 510, shares: 22, earnings: 45 },
    { date: 'Aug 8', views: 880, reads: 620, visitors: 790, shares: 35, earnings: 72 },
    { date: 'Aug 12', views: 1240, reads: 890, visitors: 1110, shares: 58, earnings: 115 },
    { date: 'Aug 16', views: 1650, reads: 1180, visitors: 1490, shares: 74, earnings: 160 },
    { date: 'Aug 20', views: 2410, reads: 1720, visitors: 2190, shares: 112, earnings: 240 },
    { date: 'Aug 24', views: 3120, reads: 2240, visitors: 2850, shares: 146, earnings: 310 },
    { date: 'Aug 27', views: 2890, reads: 2060, visitors: 2610, shares: 128, earnings: 285 },
  ],
  trafficSources: [
    { source: 'Direct & Premium Share Links', percentage: 38, visitors: 6560, color: '#6366f1' },
    { source: 'Search Engines (Organic SEO)', percentage: 26, visitors: 4490, color: '#0ea5e9' },
    { source: 'Substack & Newsletters', percentage: 18, visitors: 3108, color: '#10b981' },
    { source: 'X / Twitter & Mastodon', percentage: 12, visitors: 2072, color: '#f59e0b' },
    { source: 'Hacker News & Reddit', percentage: 6, visitors: 1040, color: '#ec4899' },
  ],
  devices: [
    { device: 'Desktop / Laptop', percentage: 56, count: 9671 },
    { device: 'Mobile Phones (iOS & Android)', percentage: 38, count: 6562 },
    { device: 'Tablets & E-Readers', percentage: 6, count: 1037 },
  ],
  geo: [
    { country: 'United States', flag: '🇺🇸', visitors: 7250, percentage: 42 },
    { country: 'United Kingdom', flag: '🇬🇧', visitors: 2420, percentage: 14 },
    { country: 'Germany', flag: '🇩🇪', visitors: 1730, percentage: 10 },
    { country: 'Canada', flag: '🇨🇦', visitors: 1380, percentage: 8 },
    { country: 'Japan', flag: '🇯🇵', visitors: 1035, percentage: 6 },
    { country: 'Other Global Regions', flag: '🌐', visitors: 3455, percentage: 20 },
  ],
};

export const INITIAL_COMMENTS: StoryComment[] = [
  {
    id: 'c1',
    postId: 'post-1',
    authorName: 'Marcus Sterling',
    authorAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    content: 'The point about cognitive decay and intentional friction resonated deeply with our design team. We just replaced 4 badge popups with quiet inline hints.',
    createdAt: '2 days ago',
    likes: 24,
  },
  {
    id: 'c2',
    postId: 'post-1',
    authorName: 'Aria Chen',
    authorAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    content: 'The markdown preview layout is breathtaking. Will definitely share this with my fellow engineering writers!',
    createdAt: '1 day ago',
    likes: 15,
  }
];

export const CATEGORIES = [
  'All Stories',
  'Design & Craft',
  'Engineering',
  'Economics',
  'Literature',
  'Mindfulness',
  'Technology'
];
