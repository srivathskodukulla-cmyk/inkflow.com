export type PostStatus = 'draft' | 'published' | 'scheduled';
export type PaywallType = 'free' | 'metered' | 'premium_only';
export type ReaderFont = 'serif' | 'sans' | 'mono';
export type PremiumTier = 'free' | 'pro' | 'studio';

export interface Author {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  bio: string;
  tier: PremiumTier;
  followersCount: number;
  isVerified?: boolean;
}

export interface StoryComment {
  id: string;
  postId: string;
  authorName: string;
  authorAvatar: string;
  content: string;
  createdAt: string;
  likes: number;
}

export interface Post {
  id: string;
  title: string;
  subtitle: string;
  slug: string;
  content: string;
  coverImage: string;
  tags: string[];
  category: string;
  author: Author;
  status: PostStatus;
  publishedAt: string;
  updatedAt: string;
  readTime: number; // in minutes
  wordCount: number;
  isPremium: boolean;
  paywallType: PaywallType;
  premiumPrice?: number;
  claps: number;
  bookmarksCount: number;
  viewsCount: number;
  readsCount: number;
  commentsCount: number;
  sharesCount: number;
  customShareSlug?: string;
  allowComments: boolean;
  featured?: boolean;
}

export interface AnalyticsTimelinePoint {
  date: string;
  views: number;
  reads: number;
  visitors: number;
  shares: number;
  earnings: number;
}

export interface TrafficSource {
  source: string;
  percentage: number;
  visitors: number;
  color: string;
}

export interface DeviceStat {
  device: string;
  percentage: number;
  count: number;
}

export interface GeoStat {
  country: string;
  flag: string;
  visitors: number;
  percentage: number;
}

export interface AudienceAnalyticsData {
  overview: {
    totalViews: number;
    viewsGrowth: number;
    totalReads: number;
    readsGrowth: number;
    avgReadRatio: number;
    avgReadTimeMinutes: number;
    totalShares: number;
    sharesGrowth: number;
    totalRevenue: number;
    revenueGrowth: number;
    subscriberGains: number;
  };
  timeline: AnalyticsTimelinePoint[];
  trafficSources: TrafficSource[];
  devices: DeviceStat[];
  geo: GeoStat[];
}

export interface UserProfile {
  id: string;
  name: string;
  handle: string;
  email: string;
  avatar: string;
  bio: string;
  tier: PremiumTier;
  subscriptionActive: boolean;
  subscriptionRenewDate?: string;
  totalEarnings: number;
  unpaidBalance: number;
  followersCount: number;
  followingCount: number;
  sharesRemainingForFree: number;
}
